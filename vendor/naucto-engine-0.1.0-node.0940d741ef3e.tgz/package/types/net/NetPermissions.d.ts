export interface NetPermissions {
    canClientWrite(path: string): boolean;
    canClientRead(path: string): boolean;
}
export declare const ALLOW_ALL: NetPermissions;
/** What a net.state entry can hold. Scalars only: a table is its own leaves. */
export type NetScalar = number | string | boolean;
/**
 * One declaration in the game document: which clients may reach this path, and what a session
 * starts it at.
 *
 * The default is the authored starting value, not the live one. A running session owns its values
 * and they are not versioned; this is what a fresh session begins with, so a declaration can be
 * reviewed, reverted and diffed like the rest of the document, while a game in progress is left
 * alone.
 */
export interface NetDeclaration {
    flags: number;
    default?: NetScalar;
}
/**
 * The branch a lock or queue keeps its backing under, and the one name no declaration may use.
 *
 * `SharedTableSession` stores an object's type, its lock owner and its queue in
 * `P.__netobj__.*` and resolves permissions against the *owner's* path, so a declaration here would
 * be two things at once: a value seeded into the host's store where the lock machinery reads it
 * (an owner written there deadlocks the first acquisition, permanently), and a permission nobody
 * consults. It is not a path a person or an assistant may name.
 */
export declare const NET_RESERVED_SEGMENT = "__netobj__";
/** The longest declaration the document will hold, so a path cannot become a payload. */
export declare const NET_PATH_MAX = 128;
export declare const isNetSegment: (value: string) => boolean;
/**
 * Whether a string is a shape a net.state declaration may be keyed by. The empty string is
 * deliberately not one: a root entry of `0` is how a game closes the whole table, and it is
 * written by the resolver, not declared as a path.
 */
export declare const isNetPath: (value: string) => boolean;
