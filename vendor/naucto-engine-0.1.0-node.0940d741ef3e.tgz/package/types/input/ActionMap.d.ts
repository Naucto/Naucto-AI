/** A name the game gives one of the engine's actions, for the controls table and "how to play". */
export interface DeclaredAction {
    action: Action;
    label: string;
}
export declare const ACTIONS: readonly ["left", "right", "up", "down", "a", "b", "x", "y", "pause"];
export type Action = (typeof ACTIONS)[number];
export declare const ACTION_BIT: Record<Action, number>;
export declare const MAX_PLAYERS = 4;
export interface GamepadButtonRef {
    /** Standard-mapping button index, or axis ref. */
    button?: number;
    axis?: number;
    /** +1 or -1 for axes. */
    direction?: 1 | -1;
}
export interface ActionBindings {
    /** Per player (index 0 = player 1): action → event.key names. */
    keyboard: Record<Action, string[]>[];
    gamepad: Record<Action, GamepadButtonRef[]>;
}
export declare const DEFAULT_BINDINGS: ActionBindings;
export declare const isAction: (v: unknown) => v is Action;
