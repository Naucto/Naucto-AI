/** How a map reaches the document. The game supplies it, as it does a sheet's. */
export interface MapWriter {
    setTile(mapId: string, x: number, y: number, sprite: number): void;
}
/**
 * One tile map of a game.
 *
 * A projection over the document, like {@link Sheet}. Its tiles are sprite numbers, and those run
 * across every sheet, so a map is not tied to one of them.
 */
export declare class GameMap {
    readonly id: string;
    readonly name: string;
    readonly order: number;
    readonly width: number;
    readonly height: number;
    /** Palette slot this map is marked with, or null where it takes none. */
    readonly colour: number | null;
    /** Sprite numbers, row-major. Replaced when the map is resized, so do not hold it. */
    readonly tiles: Uint16Array;
    private readonly writer;
    constructor(id: string, name: string, order: number, width: number, height: number, 
    /** Palette slot this map is marked with, or null where it takes none. */
    colour: number | null, 
    /** Sprite numbers, row-major. Replaced when the map is resized, so do not hold it. */
    tiles: Uint16Array, writer: MapWriter);
    getTile(x: number, y: number): number;
    setTile(x: number, y: number, sprite: number): void;
}
