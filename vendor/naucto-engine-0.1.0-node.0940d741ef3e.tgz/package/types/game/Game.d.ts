import * as Y from 'yjs';
import { type DeclaredAction } from '../input/ActionMap';
import type { NetDeclaration } from '../net/NetPermissions';
import type { Instrument, Pattern, Song } from '../sound/model';
import { GameMap } from './GameMap';
import { type Geometry } from './geometry';
import { Sheet } from './Sheet';
/** What a resize would move, and what it would cost. */
export interface ResizePreview {
    /** Sprite numbers that would come to mean a different cell. */
    moves: number;
    /** Map tiles that name one of them. */
    tiles: number;
    /** Calls in the project's code that would be rewritten. */
    calls: number;
    /** Calls that name a sprite through something other than a plain number, so nothing can follow. */
    unsure: number;
    /** Cells with something drawn on them that would fall outside the new shape. */
    lost: number;
}
export interface PixelChange {
    /** Which sheet the pixel is on. Without it a change on the second lands on the first. */
    sheet: string;
    x: number;
    y: number;
    colour: number;
}
export interface TileChange {
    /** Which map the tile is on. Without it a change on the second lands on the first. */
    map: string;
    x: number;
    y: number;
    sprite: number;
}
type Unsubscribe = () => void;
export interface CodeFile {
    id: string;
    name: string;
    order: number;
    /** Palette slot this file is labelled with, or null when it takes none. */
    colour: number | null;
    text: Y.Text;
}
/** Origin of a tool-local transaction so observers can tell local edits from remote ones. */
export declare const LOCAL_ORIGIN = "local";
/**
 * Typed, observable access to a game document (Yjs). Materialises the sprite
 * sheet, flags and tile map as typed arrays kept in sync from Yjs events so the
 * renderer and editors never iterate 16k map entries per frame.
 */
export declare class Game {
    readonly doc: Y.Doc;
    readonly meta: Y.Map<unknown>;
    readonly codeFiles: Y.Map<Y.Map<unknown>>;
    readonly codeMeta: Y.Map<string>;
    readonly paletteArray: Y.Array<string>;
    readonly spritesMap: Y.Map<number>;
    readonly flagsMap: Y.Map<number>;
    readonly tilesMap: Y.Map<number>;
    /**
     * The sheets and the maps a game has, beyond the first of each.
     *
     * The first entry of either names the content already under `gfx.sprites`, `gfx.flags` and
     * `map.tiles` rather than holding its own -- see {@link FIRST_SHEET_ID}.
     */
    readonly sheetsMap: Y.Map<Y.Map<unknown>>;
    readonly mapsMap: Y.Map<Y.Map<unknown>>;
    readonly instruments: Y.Map<string>;
    readonly patterns: Y.Map<string>;
    readonly sfx: Y.Map<string>;
    readonly songs: Y.Map<string>;
    readonly samples: Y.Map<string>;
    readonly netPermissions: Y.Map<NetDeclaration>;
    /**
     * Palette indices of the first sheet, row-major, one byte a pixel.
     *
     * The first sheet's mirror under an older name, and nothing more: it is built, hydrated and
     * reshaped by exactly the code that does it for every other sheet. Replaced when the sheet is
     * resized, so hold it for the length of a draw and no longer.
     */
    get sheet(): Uint8Array;
    /** One byte of flags per sprite, for the first sheet. */
    get flags(): Uint8Array;
    /**
     * Sprite numbers of the first map, row-major, one per tile.
     *
     * Sixteen bits rather than eight: a sheet may hold more than 256 sprites, and a tile that could
     * not name them would put most of a sheet out of a map's reach.
     */
    get tiles(): Uint16Array;
    private _geometry;
    private readonly geometryListeners;
    private readonly collectionListeners;
    private readonly sheetMirrors;
    /** The projections as last built, or null once the document has moved under them. */
    private sheetsHeld;
    private mapsHeld;
    /**
     * How a Sheet reaches the document.
     *
     * A separate object rather than the game itself: Game already has setPixel and setFlag, and they
     * mean the first sheet's -- two things called the same thing, one of which silently ignores the
     * sheet you meant, is the sort of collision that only shows up in someone's lost art.
     */
    private readonly sheetWriter;
    private readonly mapMirrors;
    private readonly mapWriter;
    /** Cell maps already watched, so a second pass over the collection does not double up. */
    private readonly watchedCells;
    private readonly pixelListeners;
    private readonly tileListeners;
    private readonly flagListeners;
    private readonly paletteListeners;
    constructor(doc: Y.Doc);
    /** Entries of a collection, sorted the way code files are: by order, then by name. */
    private orderedEntries;
    /**
     * The live pixel and flag mirrors of one sheet, made on first ask and reshaped when it resizes.
     *
     * Every sheet the same, the first one included: its cells are at the document's roots rather
     * than under its entry, and `cellsOf` is the one place that knows it. Anything outside the shape
     * is dropped rather than refused -- a document written larger and opened smaller is not corrupt,
     * it is one this reader can only show part of, and nothing here writes back.
     */
    private sheetMirror;
    private mapMirror;
    /**
     * Drops the held projections, so the next read builds them from the document.
     *
     * Called from the collection observers and from a geometry change, which between them see every
     * write that can alter a projection: an entry added, removed, renamed, reordered or resized,
     * locally or from a peer, and a first sheet or map resized through the document's meta. A cell
     * written into a mirror is not one of them -- the mirror is the same buffer the projection holds.
     */
    private forgetProjections;
    /**
     * Every sheet, in order, with its sprite numbers already worked out.
     *
     * A document that declares none has one all the same: an empty entry, which takes the document's
     * geometry the way any sheet that states no size of its own does. Written that way rather than as
     * a sheet built by hand, so the one below is the only place a sheet is ever made.
     *
     * Held between document changes: the renderer asks for the sheet of every sprite it draws, and
     * walking Yjs for each would cost a frame its budget. Inside a local transaction the held array
     * lags the write until the observers run at its end; the two reads that happen there -- the
     * order an added entry takes, and the shape a renumbering started from -- want exactly the
     * answer from before the write.
     */
    get sheets(): Sheet[];
    get maps(): GameMap[];
    /**
     * A collection's entries, or the one every game has when it declares nothing.
     *
     * The empty entry is not written to the document -- reading a game must not change it -- it only
     * stands in so that the first sheet and the first map are built by the same code as the rest.
     */
    private entriesOrDefault;
    /**
     * Where a sheet's cells are, or nothing where it has none yet.
     *
     * The first sheet's are the document's own roots -- `gfx.sprites` and `gfx.flags` -- because a
     * game written before a game could have several put them there, and moving them would make this
     * build's documents unreadable to that one. **This is the one place that knows it**, and its
     * twin below is the one place that knows where its size is. Everything else treats every sheet
     * alike.
     */
    private cellsOf;
    /** Where the first map's tiles are, and where any other map's would be. */
    private mapCellsOf;
    /**
     * How big a sheet is: what its entry states, or the document's geometry where it states nothing.
     *
     * The same rule for every sheet. The geometry is not the first sheet's private size, it is the
     * default a sheet takes when it names none -- which is the state every sheet of every game
     * written before collections is in.
     */
    private sizeOf;
    /**
     * Writes a sheet's size where `sizeOf` reads it -- on its entry, for every sheet alike.
     *
     * The first sheet's is mirrored into the geometry as well, and that is the whole of what is
     * special about it: `meta.sheetWidth` is where a build from before collections reads the size of
     * the only sheet it knows about, and where this one takes its default from. Mirrored rather than
     * chosen between, because a size written in one of the two places and read from the other is how
     * a picture comes to be read at one width out of a buffer laid out at another.
     */
    private writeSheetSize;
    /** The same, for a map. */
    private writeMapSize;
    /** The same, for a map. */
    private mapSizeOf;
    /**
     * Where a sheet's cells go when something writes to them.
     *
     * Made on the first write rather than at creation, so a sheet nobody has drawn on costs the
     * document nothing.
     */
    private sheetCells;
    /**
     * The tile twin of `sheetCells`: a map's cells, made the first time something writes one.
     *
     * Not watched here: a map made and written in one transaction fires no event of its own, Yjs
     * only reporting on types that were there when the transaction began. The collection observer
     * watches it once the transaction ends, and tells the tiles it arrived with.
     */
    private mapCells;
    /** Watches the cell maps of every sheet that has any, once each. */
    private attachSheetObservers;
    /** The same for the maps, whose tiles the first one keeps at the document's root. */
    private attachMapObservers;
    /**
     * Keeps one sheet's mirror in step with its cells.
     *
     * Attached as the cell maps appear, so the listeners hear about them the same way -- a peer
     * drawing on a sheet nobody has opened still has to reach the screen.
     */
    /** Brings a sheet's mirror in step with these cells and tells the listeners what moved. */
    private tellCells;
    private observeSheetCells;
    /** Brings the mirror in step with these cells and tells the listeners which tiles moved. */
    private tellTiles;
    /** The tile twin of `observeSheetCells`. */
    private observeMapCells;
    private writeSheetPixel;
    private writeSheetFlag;
    private writeMapTile;
    /**
     * Adds a sheet after the ones there are, and gives it the numbers that follow theirs.
     *
     * The first call also writes the entry for the sheet that was already there, because a document
     * cannot hold a second sheet without saying what the first one is.
     */
    addSheet(name: string, width: number, height: number, id?: string): void;
    /** Resizes a sheet other than the first, whose size is the document's own. */
    /**
     * What resizing a sheet would cost, without doing it.
     *
     * A sheet's pixels are kept by position, so a resize keeps the picture and re-flows the grid of
     * numbers over it: the same cell answers to a different number afterwards, and so does every cell
     * of every sheet after this one. Anything that named a number by hand has to follow.
     */
    previewResize(id: string, width: number, height: number): ResizePreview;
    /**
     * Resizes a sheet and brings everything that named a sprite number along with it.
     *
     * One transaction for the sizes, the flags, the tiles and the code: a document caught halfway is
     * one where a number means two things at once, and a peer joining then would read exactly that.
     */
    resizeSheet(id: string, width: number, height: number): void;
    /**
     * Resizes one map. Nothing is renumbered: a tile keeps its place, and the first map's size
     * reaches the geometry through the writer, as it always did.
     */
    resizeMap(id: string, width: number, height: number): void;
    /**
     * Everything that names a sprite by number, copied out before the sizes move.
     *
     * Read first because the projections below are rebuilt from the document on every access: once
     * the sizes have changed they describe the new arrangement, and what has to be moved is what the
     * old one said.
     */
    private holdNumbered;
    /**
     * Moves the tiles, the flags and the code onto the numbers the new shape gives them.
     *
     * Written straight into the document's maps rather than through `setFlag` and `setTile`: this
     * runs inside the same transaction as the resize, and until that transaction ends the observers
     * have not fired, so those two are still guarding against the sizes the game had a moment ago.
     * The new shape is passed in for the same reason.
     */
    private renumber;
    /** The sheets as they would be, in order, if this one took that size. */
    private shapesAfterResize;
    /** A colour of null takes none, rather than taking slot zero. */
    describeSheet(id: string, name: string, colour: number | null): void;
    describeMap(id: string, name: string, colour: number | null): void;
    private describe;
    /** Refuses the last one, the way a code file does: a game with no sheet has nowhere to draw. */
    removeSheet(id: string): void;
    addMap(name: string, width: number, height: number, id?: string): void;
    removeMap(id: string): void;
    /**
     * Writes the entry describing the sheet a document already had.
     *
     * Its key is fixed rather than fresh, so two clients doing this at once write the same entry
     * instead of splitting one sheet into two -- the same reason the entry file's key is fixed.
     */
    private declareFirstSheet;
    private declareFirstMap;
    /** Which sheet answers to a sprite number, or nothing where the number names no cell. */
    sheetOf(sprite: number): Sheet | undefined;
    mapOf(id: string): GameMap | undefined;
    /** One past the highest sprite number any sheet claims. */
    get spriteTotal(): number;
    /** How big this game's sheet and map are. Read it per use; a resize replaces it. */
    get geometry(): Geometry;
    onGeometryChange(fn: () => void): () => void;
    /**
     * Told when a sheet or a map is added, removed or renamed.
     *
     * The collections are Yjs maps, not signals, so anything derived from them has no way of its own
     * to know it has gone stale -- and two things derived from the same collection at different
     * moments will disagree, which is how a panel came to show three sheets beside a count of one.
     */
    onCollectionsChange(fn: () => void): () => void;
    /**
     * Takes a size the document now states, and says so.
     *
     * Nothing is reshaped here: a mirror carries the shape it was built at and `sheetMirror` makes a
     * new one the moment it is asked for a different one, so the next read does it.
     */
    private applyGeometry;
    /**
     * Records a new size. Pixels and tiles outside it stay in the document but stop being reachable,
     * so growing back finds them again -- which is what makes a mis-click survivable.
     */
    resize(size: {
        sheetWidth?: number;
        sheetHeight?: number;
        mapWidth?: number;
        mapHeight?: number;
    }): void;
    get schemaVersion(): number;
    get compat(): boolean;
    /**
     * The names the game gives its actions, typed in the GAME tab and persisted so the controls table
     * and the public "how to play" can show them without running the game. Empty when it names none,
     * in which case callers fall back to the engine's action ids.
     */
    get declaredActions(): readonly DeclaredAction[];
    /** An action with a blank label is an action left unnamed, so it is not written at all. */
    setDeclaredActions(actions: readonly DeclaredAction[]): void;
    get palette(): string[];
    setPaletteColour(index: number, hex: string): void;
    setPalette(colours: readonly string[]): void;
    onPaletteChange(l: () => void): Unsubscribe;
    /**
     * The first sheet's pixels, which is what `gfx.pixel` and the like have always meant.
     *
     * Asked of the sheet rather than worked out here: a second copy of "where is pixel x,y" is a
     * second chance to disagree with the first the day a sheet is not 128 wide.
     */
    getPixel(x: number, y: number): number;
    setPixel(x: number, y: number, colour: number): void;
    /** Batch pixel writes into one transaction (one undo step, one network update). */
    transact(fn: () => void, origin?: unknown): void;
    onPixelsChange(l: (changes: PixelChange[]) => void): Unsubscribe;
    /**
     * Where a sprite number starts, on the sheet that answers to it.
     *
     * The one authority on how a number becomes a position: the renderer and both editors used to
     * each carry their own copy of this arithmetic, and four copies are four chances to disagree the
     * day a number no longer names a place on one fixed sheet.
     *
     * A number no sheet claims lands at the origin of the first, which is what every caller did with
     * an out-of-range number before there was anywhere else for one to be.
     */
    spriteOrigin(index: number): {
        x: number;
        y: number;
    };
    isSpriteEmpty(index: number): boolean;
    getFlag(index: number): number;
    getFlagBit(index: number, bit: number): boolean;
    setFlag(index: number, value: number): void;
    onFlagsChange(l: () => void): Unsubscribe;
    /** The first map's tile, as `getPixel` is the first sheet's pixel: the one every game has. */
    getTile(x: number, y: number): number;
    setTile(x: number, y: number, sprite: number): void;
    onTilesChange(l: (changes: TileChange[]) => void): Unsubscribe;
    get files(): CodeFile[];
    get entryFile(): CodeFile | undefined;
    /**
     * `id` is only passed when the key has to be reproducible across clients — the entry file, so a
     * concurrent seed converges instead of merging into two entries. Everything else gets a UUID.
     */
    addFile(name: string, source?: string, id?: string): CodeFile;
    renameFile(id: string, name: string): void;
    /**
     * Ids first to last; anything not named keeps its place after them.
     *
     * One transaction rather than one write per file: the order decides what runs when, so every
     * observer downstream reloads the game on it, and N writes would mean N reloads of an order that
     * was only ever moved once.
     */
    reorderFiles(ids: readonly string[]): void;
    setFileColour(id: string, colour: number | null): void;
    removeFile(id: string): void;
    /**
     * Every file's source in the order the tabs are in — which is the order they are evaluated.
     *
     * A file's name is also the name anything asking for it by name would use.
     */
    sources(): {
        name: string;
        source: string;
    }[];
    private parseMap;
    getInstruments(): Map<string, Instrument>;
    getPatterns(): Map<string, Pattern>;
    getSongs(): Map<string, Song>;
    /** sfx slot ("0".."15") → pattern id */
    getSfxSlots(): Map<string, string>;
    setInstrument(i: Instrument): void;
    setPattern(p: Pattern): void;
    setSong(slot: number, s: Song): void;
    /**
     * Puts a saved snapshot back, as content rather than as history.
     *
     * `Y.applyUpdate` cannot do this, and the editor spent its whole life believing it could. A
     * version blob is `encodeStateAsUpdate` of *this same document* at an earlier moment, so every
     * operation it carries is already in this document: applying it back is, by the CRDT's own
     * rules, a no-op. Restoring a version reported success and changed nothing.
     *
     * So a restore is written as ordinary edits — which is also what makes it reach everyone else in
     * the session, land in the undo stack, and autosave like any other change. Only the differences
     * are written, so restoring a version that only touched code does not rewrite 16k map cells.
     */
    restoreFrom(update: Uint8Array): void;
    /**
     * Sheets and maps are entries holding their own nested maps of cells, so — like files — they
     * cannot be copied by value. An entry the snapshot does not have goes, or restoring an old
     * version would leave today's sheets standing beside it and the game would be two states at once.
     */
    private restoreCollection;
    /** Files are maps of maps holding a `Y.Text`, so they cannot be copied by value. */
    private restoreFiles;
    /** Fills an empty document with the starter game. Idempotent. */
    seedDefaults(): void;
    /**
     * Repairs a document seeded twice before {@link MAIN_FILE_ID} existed.
     *
     * Conservative on purpose: it keeps whichever entry holds the most text and drops the others
     * only when they are empty or hold exactly the same source. A duplicate that somehow diverged is
     * left alone and renamed out of the way, because losing a line of someone's Lua to a tidy-up is
     * worse than an odd file name.
     */
    private dedupeEntryFile;
    seedDefaultSprite(colour: number): void;
}
export {};
