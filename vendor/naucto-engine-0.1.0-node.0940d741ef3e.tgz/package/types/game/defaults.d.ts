/** Bubblegum 16 by PineTreePizza (via lospec) — default palette of a new game. */
export declare const BUBBLEGUM_16: readonly ["#16171a", "#7f0622", "#d62411", "#ff8426", "#ffd100", "#fafdff", "#ff80a4", "#ff2674", "#94216a", "#430067", "#234975", "#68aed4", "#bfff3c", "#10d275", "#007899", "#002859"];
/** PICO-8 palette — what v0 games were drawn with; kept on migration so old art is unchanged. */
export declare const PICO8_PALETTE: readonly ["#000000", "#1d2b53", "#7e2553", "#008751", "#ab5236", "#5f574f", "#c2c3c7", "#fff1e8", "#ff004d", "#ffa300", "#ffec27", "#00e436", "#29adff", "#83769c", "#ff77a8", "#ffccaa"];
export declare const DEFAULT_GAME_CODE = "-- Naucto starter game\n-- Move the moon with the arrow keys, WASD or a gamepad.\n\nlocal player = {\n  x = 152,\n  y = 82,\n  speed = 2,\n}\n\nfunction _init()\n  print(\"Welcome to Naucto!\")\nend\n\nfunction _update()\n  if input.held(\"left\") then player.x = player.x - player.speed end\n  if input.held(\"right\") then player.x = player.x + player.speed end\n  if input.held(\"up\") then player.y = player.y - player.speed end\n  if input.held(\"down\") then player.y = player.y + player.speed end\nend\n\nfunction _draw()\n  gfx.clear(0)\n  -- The moon is a 16x16 block of the sheet, drawn in one go.\n  gfx.draw_region(8, 0, 16, 16, player.x, player.y)\nend\n";
/** 16×16 moon drawn into sprites 1, 2, 17, 18 ('a' = gold, '.' = transparent). */
export declare const DEFAULT_PLAYER_SPRITE: readonly [".....aaaaaa.....", "....aaaaaaaaa...", "...aa.aaaaaaa...", "..aa...aaa......", "..a.....a.......", ".aaa...a........", ".aaaa.aa........", ".aaaaaa.........", ".aaaaaa........a", ".aaaaaaa......aa", "..aaaaaa.....aaa", "..aaaaaaa...aaaa", "...aaaaaaaaaaaa.", "....aaaaaaaaaa..", ".....aaaaaaaa...", "................"];
export declare const DEFAULT_PLAYER_SPRITE_INDICES: readonly [1, 2, 17, 18];
/** Palette slot used for the default sprite (gold in Bubblegum, yellow in PICO-8). */
export declare const DEFAULT_SPRITE_COLOUR = 4;
export declare const DEFAULT_SPRITE_COLOUR_V0 = 10;
