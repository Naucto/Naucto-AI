/**
 * How big a game's sheet and map are, in the units each of them is measured in.
 *
 * These were constants until games started running out of room. They are read from the document
 * now, so the numbers below are only what a document that says nothing is taken to mean -- which is
 * exactly what every game written before this held.
 */
export interface Geometry {
    /** Sheet, in pixels. Always a whole number of sprites. */
    readonly sheetWidth: number;
    readonly sheetHeight: number;
    /** The same sheet, in sprites -- the units a sprite number is counted in. */
    readonly spritesPerRow: number;
    readonly spriteRows: number;
    readonly spriteCount: number;
    /** Map, in tiles. */
    readonly mapWidth: number;
    readonly mapHeight: number;
}
/** Sizes move a whole sprite at a time: half a sprite is a sprite cut across a boundary. */
export declare const SIZE_STEP = 8;
export declare const MIN_SHEET_SIZE = 8;
export declare const MAX_SHEET_SIZE = 256;
export declare const MIN_MAP_SIZE = 1;
export declare const MAX_MAP_SIZE = 256;
export declare const GEOMETRY_KEYS: {
    readonly sheetWidth: "sheetWidth";
    readonly sheetHeight: "sheetHeight";
    readonly mapWidth: "mapWidth";
    readonly mapHeight: "mapHeight";
};
/** A size snapped to whole sprites and held inside its range. */
export declare function clampSheetSize(n: number): number;
export declare function clampMapSize(n: number): number;
export declare function geometryOf(sheetWidth: number, sheetHeight: number, mapWidth: number, mapHeight: number): Geometry;
/** What a document that records no size is taken to mean. */
export declare const DEFAULT_GEOMETRY: Geometry;
export declare function readGeometry(meta: {
    get(key: string): unknown;
}): Geometry;
