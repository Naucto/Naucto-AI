/**
 * Yjs key layout of a game document and the legacy v0 keys it replaces.
 *
 * The keys are schema v1's; v2 renamed functions in the code and moved the action labels out of
 * it, and changed no key.
 */
export declare const GAME_SCHEMA_VERSION = 2;
export declare const KEYS: {
    readonly meta: "game.meta";
    readonly codeFiles: "code.files";
    readonly codeMeta: "code.meta";
    readonly palette: "gfx.palette";
    readonly sheets: "gfx.sheets";
    readonly sprites: "gfx.sprites";
    readonly flags: "gfx.flags";
    readonly maps: "map.maps";
    readonly tiles: "map.tiles";
    readonly instruments: "sound.instruments";
    readonly patterns: "sound.patterns";
    readonly sfx: "sound.sfx";
    readonly songs: "sound.songs";
    readonly samples: "sound.samples";
    readonly netPermissions: "net.permissions";
    readonly projectName: "projectName";
    readonly shortDescription: "shortDescription";
    readonly longDescription: "longDescription";
    readonly iconUrl: "iconUrl";
    readonly projectTags: "projectTags";
};
export declare const LEGACY_KEYS: {
    readonly code: "monaco";
    readonly sprites: "sprite";
    readonly flags: "sprite_flags";
    readonly tiles: "map";
    readonly musics: "sound_musics";
    readonly selectedMusic: "sound_selectedIndex";
    readonly customInstruments: "sound_customInstruments";
    readonly netPermissions: "multiplayerDirectory";
};
export declare const SCREEN_WIDTH = 320;
export declare const SCREEN_HEIGHT = 180;
export declare const SPRITE_SIZE = 8;
export declare const SHEET_WIDTH = 128;
export declare const SHEET_HEIGHT = 128;
export declare const SPRITES_PER_ROW: number;
export declare const SPRITE_COUNT: number;
export declare const MAP_WIDTH = 128;
export declare const MAP_HEIGHT = 32;
export declare const PALETTE_SIZE = 16;
export declare const MAIN_FILE = "main";
/**
 * The entry file's key in `code.files` is fixed rather than a fresh UUID.
 *
 * Two clients that open the same still-empty document both run `seedDefaults`, and with a random id
 * each the Yjs merge keeps *both* — which is how the editor ended up showing the entry twice.
 * A constant key makes the two writes the same write, so the CRDT converges on one file.
 */
export declare const MAIN_FILE_ID = "main";
/**
 * The first sheet's and the first map's keys, fixed for the reason {@link MAIN_FILE_ID} is.
 *
 * They also mean something the others do not: these two entries describe the pixels and tiles that
 * already live under `gfx.sprites`, `gfx.flags` and `map.tiles`, and keep living there. Moving that
 * content under the collection would rewrite every non-empty cell of every game in existence, cost
 * a tombstone apiece, and leave a client that predates the collection looking at an empty game.
 * Left where it is, such a client sees the first sheet and the first map exactly as it always did.
 */
export declare const FIRST_SHEET_ID = "0";
export declare const FIRST_MAP_ID = "0";
