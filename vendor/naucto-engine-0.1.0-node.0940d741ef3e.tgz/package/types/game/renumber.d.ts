import type { SheetShape } from './Sheet';
/**
 * Old sprite number to new one, for every number that still names a cell.
 *
 * A number missing from it names a cell that is gone. A number equal to itself is left out too —
 * the map only carries what moves, so an empty map means nothing has to be rewritten at all.
 */
export type SpriteRemap = ReadonlyMap<number, number>;
/** The shape a sheet is, before or after: enough to say where each of its cells sits. */
type Shape = Pick<SheetShape, 'id' | 'width' | 'height' | 'base'>;
/**
 * What every sprite number becomes when the sheets change shape.
 *
 * A sheet's pixels are stored by position, not by cell, so resizing one keeps the picture and
 * re-flows the grid over it: at sixteen columns the cell at column one of row one is number 17, and
 * at twenty-four columns the same cell is number 25. Every sheet after it shifts as well, because
 * numbers run on from one sheet to the next.
 *
 * A cell that falls outside the new shape has no number at all, and is left out.
 */
export declare function remapSprites(before: readonly Shape[], after: readonly Shape[]): SpriteRemap;
/** Whether a sprite number still names a cell after the change. */
export declare function survives(n: number, before: readonly Shape[], after: readonly Shape[]): boolean;
export interface Rewrite {
    text: string;
    /** Calls whose number was moved to a new one. */
    changed: number;
    /**
     * Calls that name a sprite through something other than a plain number.
     *
     * Nothing can be done for these — the value is only known while the game runs — so they are
     * counted and reported rather than guessed at.
     */
    unsure: number;
}
/**
 * Rewrites the sprite numbers written into a Lua source.
 *
 * Scanned rather than parsed: the only parser in the tree throws on incomplete code, which is the
 * state a file in an editor is in most of the time. So this reads the source once, keeping track of
 * whether it is inside a string or a comment, and only looks at calls it recognises by name.
 */
export declare function rewriteSpriteNumbers(source: string, remap: SpriteRemap): Rewrite;
export {};
