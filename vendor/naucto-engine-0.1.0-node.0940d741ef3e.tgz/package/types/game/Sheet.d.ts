/**
 * One sprite sheet of a game.
 *
 * A projection over the document, the way a code file is: the pixels are a mirror the game keeps in
 * step, and the methods here are the arithmetic that turns a sprite number into a place on it.
 */
export interface SheetShape {
    readonly id: string;
    readonly name: string;
    readonly order: number;
    readonly width: number;
    readonly height: number;
    /**
     * The first sprite number this sheet answers to.
     *
     * Sprite numbers run on from one sheet to the next, so a sheet's own cells are `base` to
     * `base + count - 1`. Nothing outside this file should do that addition itself.
     */
    readonly base: number;
    readonly colour: number | null;
}
/** How a sheet reaches the document. The game supplies it; nothing else needs to know the shape. */
export interface SheetWriter {
    setPixel(sheetId: string, x: number, y: number, colour: number): void;
    setFlag(sheetId: string, local: number, value: number): void;
}
export declare class Sheet implements SheetShape {
    readonly id: string;
    readonly name: string;
    readonly order: number;
    readonly width: number;
    readonly height: number;
    readonly base: number;
    /** Palette slot this sheet is marked with, or null where it takes none. */
    readonly colour: number | null;
    /** Palette indices, row-major. Replaced when the sheet is resized, so do not hold it. */
    readonly pixels: Uint8Array;
    /** One byte per cell, indexed from 0 within this sheet rather than by sprite number. */
    readonly flags: Uint8Array;
    /** Writes reach the document through the game, which owns the Yjs side of every sheet. */
    private readonly writer;
    readonly cols: number;
    readonly rows: number;
    readonly count: number;
    constructor(id: string, name: string, order: number, width: number, height: number, base: number, 
    /** Palette slot this sheet is marked with, or null where it takes none. */
    colour: number | null, 
    /** Palette indices, row-major. Replaced when the sheet is resized, so do not hold it. */
    pixels: Uint8Array, 
    /** One byte per cell, indexed from 0 within this sheet rather than by sprite number. */
    flags: Uint8Array, 
    /** Writes reach the document through the game, which owns the Yjs side of every sheet. */
    writer: SheetWriter);
    /** Whether a sprite number is one of this sheet's. */
    holds(sprite: number): boolean;
    /** Where a sprite number starts on this sheet, in its own pixels. */
    originOf(sprite: number): {
        x: number;
        y: number;
    };
    getPixel(x: number, y: number): number;
    setPixel(x: number, y: number, colour: number): void;
    getFlag(sprite: number): number;
    setFlag(sprite: number, value: number): void;
    isEmpty(sprite: number): boolean;
}
