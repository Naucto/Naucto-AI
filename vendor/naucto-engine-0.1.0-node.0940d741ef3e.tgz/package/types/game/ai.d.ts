import * as Y from 'yjs';
import { Game } from './Game';
export declare const AI_CATEGORIES: readonly ["CODE", "SPRITES", "MAPS", "MUSIC", "SFX", "MULTIPLAYER"];
export type AiCategory = (typeof AI_CATEGORIES)[number];
/** Keys of the document the AI tooling owns next to the game itself. */
export declare const AI_KEYS: {
    readonly catalog: "ai.catalog";
    readonly levels: "ai.levels";
    readonly locks: "ai.locks";
    readonly applied: "ai.applied";
};
export interface AiLock {
    id: string;
    name: string;
    target: 'sheet' | 'map';
    resourceId: string;
    x: number;
    y: number;
    width: number;
    height: number;
}
/**
 * A semantic snapshot for the assistant, including unsaved changes. It carries no credentials and
 * nothing in it is evaluated; the assistant is told to treat all of it as data.
 */
export declare function aiContext(game: Game): Record<string, unknown>;
/** A document's full state as the backend and the editor exchange it. */
export declare function encodeState(doc: Y.Doc): string;
/** A detached game built from a state; it is not connected to collaboration or autosave. */
export declare function gameFromState(state: string): Game;
export interface AiDiff {
    code: {
        id: string;
        name: string;
        before: string;
        after: string;
    }[];
    sheets: {
        id: string;
        name: string;
        changed: number;
    }[];
    maps: {
        id: string;
        name: string;
        changed: number;
        created: boolean;
        removed: boolean;
        resized: boolean;
    }[];
    sound: {
        key: string;
        before: string;
        after: string;
    }[];
    catalog: {
        id: string;
        before: string;
        after: string;
    }[];
    levels: {
        id: string;
        before: string;
        after: string;
    }[];
    /**
     * Multiplayer declarations, in words rather than a raw JSON blob: a diff someone has to decode
     * is a diff that gets approved unread, and these decide who may read a game's own state.
     */
    net: {
        key: string;
        before: string;
        after: string;
        widened: boolean;
    }[];
}
/**
 * What a proposal changes, read off the backend's own result rather than re-derived here: the
 * preview shows exactly what applying would write, from the one validator that decides it.
 */
export declare function diffGames(before: Game, after: Game): AiDiff;
/** Locks are human configuration: the assistant reads them and the backend refuses writes inside. */
export declare function readLocks(game: Game): AiLock[];
/**
 * The runs of lines that differ between two texts, as line numbers in the new one.
 *
 * A change to a file is usually several separate edits, and a person reviewing one wants to be able
 * to take some of them. This is what the review screen offers as choices, and what the Backend
 * diffs again when asked to apply a range — it re-finds the hunks against the file as it is now,
 * so a hunk aimed by line number lands on the right edit even if the file moved in between.
 */
export declare function changedLineHunks(before: string, after: string): {
    from: number;
    to: number;
}[];
/** One row of a side-by-side diff: a line on the left, a line on the right, or both. */
export interface DiffRow {
    /** 1-based line number in the old text, absent when the line is new. */
    left?: {
        number: number;
        text: string;
    };
    /** 1-based line number in the new text, absent when the line is gone. */
    right?: {
        number: number;
        text: string;
    };
    kind: 'same' | 'changed' | 'added' | 'removed';
}
/**
 * The two texts aligned, line by line, for showing beside each other.
 *
 * A diff a person reads has to line the two versions up, or every line looks changed and nothing
 * can be taken on its own. Aligned on the longest common subsequence, so the lines that did not move
 * line up across and what is left is what actually differs — which is also the smallest unit worth
 * offering to accept.
 *
 * Quadratic, so a file past the guard is aligned only on the shared prefix and suffix. That is the
 * conservative direction: it shows more as changed rather than less, and a line wrongly offered for
 * review is a nuisance where a change wrongly hidden is a mistake.
 */
export declare function lineDiff(before: string, after: string): DiffRow[];
