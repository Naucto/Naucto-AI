/**
 * Just enough of a Lua reader to find a call by name in a file still being typed.
 *
 * The only parser in the tree throws on incomplete code, which is the state a file in an editor is
 * in most of the time. So these read a source once, keeping track of whether they are inside a
 * string or a comment, and only look at what they recognise by name.
 */
/** How far a string or a comment runs from here, or `at` where this is neither. */
export declare function skipDead(s: string, at: number): number;
/** Whether this dotted name sits here whole: not the tail of a longer name, nor the head of one. */
export declare function matchesName(s: string, at: number, name: string): boolean;
/** Whether a call by this name starts here, and is not the tail of a longer name. */
export declare function matchesCall(s: string, at: number, name: string): boolean;
/**
 * The arguments of a call whose opening bracket has just been passed.
 *
 * Split on the commas of this call only, so a nested call keeps its own. Returns nothing where the
 * bracket never closes, which is a source still being typed.
 */
export declare function splitArgs(s: string, from: number): {
    parts: string[];
    end: number;
} | null;
