import { type Instrument } from './model';
/** One playing voice. All times are in samples. */
interface Voice {
    active: boolean;
    instrument: Instrument | null;
    pitch: number;
    /** Target frequency of the note being played. */
    freq: number;
    /** Frequency actually sounding; slides towards `freq` when the instrument glides. */
    curFreq: number;
    phase: number;
    age: number;
    /** 0 attack, 1 decay, 2 sustain, 3 release, 4 done */
    stage: number;
    env: number;
    releaseAt: number;
    releaseFrom: number;
    velocity: number;
    noiseSeed: number;
    lastNoise: number;
    low: number;
    band: number;
    sample: Float32Array | null;
    samplePos: number;
    priority: number;
    /** Semitones above this voice's own note that it cycles through, empty when it holds one note. */
    arp: readonly number[];
}
/**
 * Pure-TS chip synthesiser: 5 voices, 6 oscillators, ADSR, SVF filter, vibrato,
 * arpeggio, pan. No Web Audio dependency so it renders offline in tests and
 * inside the AudioWorklet identically.
 */
export declare class SynthCore {
    readonly sampleRate: number;
    readonly voices: Voice[];
    readonly samples: Map<string, Float32Array<ArrayBufferLike>>;
    master: number;
    /** The song's fade; `musicLevel` is the volume the game asks for. Both scale the music. */
    musicGain: number;
    musicLevel: number;
    sfxGain: number;
    constructor(sampleRate: number);
    /** Start a note; returns the voice index used. `channel` forces a voice. */
    noteOn(instrument: Instrument, pitch: number, velocity: number, lengthSeconds: number, channel?: number, priority?: number, arp?: readonly number[]): number;
    noteOff(channel: number): void;
    stopAll(): void;
    isPlaying(channel: number): boolean;
    /** Render `frames` stereo samples into out[0] (left) and out[1] (right). */
    render(outL: Float32Array, outR: Float32Array, frames: number): void;
    private allocate;
    private release;
    private renderVoice;
}
export {};
