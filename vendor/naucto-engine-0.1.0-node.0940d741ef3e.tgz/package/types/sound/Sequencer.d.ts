import { type Instrument, type Pattern, type Song } from './model';
import type { SynthCore } from './SynthCore';
export interface SequencerPosition {
    pattern: number;
    step: number;
}
/**
 * Plays patterns/songs sample-accurately on top of a SynthCore. Music voices are
 * priority 0; SFX patterns run on their own lane with priority 1 so they steal
 * music voices rather than the other way round.
 */
export declare class Sequencer {
    private readonly synth;
    private readonly sampleRate;
    private song;
    private patterns;
    private instruments;
    private seqIndex;
    /** Position in the current pattern, counted in sub-steps rather than steps. */
    private subStep;
    private samplesToNextSubStep;
    private playing;
    private fade;
    private fadeRate;
    private fadeTarget;
    private stopWhenFaded;
    private readonly sfx;
    constructor(synth: SynthCore, sampleRate: number);
    setLibrary(instruments: Map<string, Instrument>, patterns: Map<string, Pattern>): void;
    /** `from` is where in the first pattern to begin, in steps; the clock rounds it onto its lattice. */
    playSong(song: Song, loop: boolean, fadeIn: number, from?: number): void;
    /**
     * Whether what is playing carries on past its last pattern.
     *
     * Asked mid-take: the chain was handed over with its own answer when playback started, and
     * without this the box could be unticked to no effect until the next start.
     */
    setLoop(loop: boolean): void;
    stopMusic(fadeOut: number): void;
    playSfx(pattern: Pattern, pitchOffset: number, volume: number, channel?: number): void;
    stopAll(): void;
    /**
     * The sub-step that is sounding, in steps and fractions of one: finer than any note position,
     * which is what a playhead has to follow to move rather than jump.
     *
     * The counter is one ahead of what is heard, since a sub-step is triggered and then counted, so
     * this reports the one before it. Whole steps are where notes sit, and a caller wanting the step
     * a note is playing on takes the floor: the fraction is how far that step has run.
     */
    position(): SequencerPosition | null;
    get isPlaying(): boolean;
    /** Advance the clock by `frames` samples, triggering notes that fall inside. */
    advance(frames: number): void;
    private advanceSong;
    private nextPattern;
    private stepSamples;
    /**
     * Samples from one sub-step to the next, spread so that the sub-steps of a step add up to exactly
     * the samples that step has always taken. A whole step therefore still falls on the sample it
     * used to; only the positions between two of them are new.
     */
    private subStepSamples;
    private triggerSubStep;
    private releaseMusicVoices;
}
