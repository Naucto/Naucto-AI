/**
 * Audio → notes: turns a recording (decoded MP3, WAV…) into a `ParsedMidi` the MIDI importer
 * converts like any MIDI file, and estimates how much of the original survives.
 *
 * Self-contained and dependency-free on purpose, like `midi.ts`: the same file runs in the
 * browser for the SOUND tab's import and in the Naucto-AI service, which checks what its own
 * rendered sounds contain. No model is involved: it is spectral analysis (harmonic summation with
 * iterative subtraction for several simultaneous notes, spectral-flux onsets, a tempo estimate),
 * so it is fast and predictable and loses a lot on dense mixes. The quality figure says how much.
 */
import type { MidiImport, ParsedMidi } from './midi';
/** Everything is analysed at this rate: enough for pitches and drum colour, cheap to process. */
export declare const ANALYSIS_RATE = 16000;
export interface TranscribeOptions {
    /** Simultaneous notes looked for per moment, 1–6. */
    voices?: number;
    /** Pitch range, MIDI notes. */
    lowest?: number;
    highest?: number;
    /** Look for drum hits (noisy onsets) and put them on their own track. */
    drums?: boolean;
    /** 0–1: higher keeps quieter notes, and more mistakes with them. */
    sensitivity?: number;
    /** Longer recordings are cut here. */
    maxSeconds?: number;
}
/** What the original recording looked like, kept to score any note list against it. */
export interface AudioAnalysis {
    frames: number;
    duration: number;
    /** Pitch-class energy per frame, `frames × 12`. */
    chroma: Float32Array;
    /** Compressed spectral energy per frame, 0–1. */
    energy: Float32Array;
    /** Linear power per frame: all of it, and the part below 4 kHz (what an 8 kHz sample keeps). */
    power: Float32Array;
    lowPower: Float32Array;
    /** Detected onsets, seconds. */
    onsets: number[];
}
export interface Quality {
    /** Estimated share of the original kept, 0–100. */
    fidelity: number;
    /** 100 − fidelity. */
    loss: number;
    /** Pitch-class similarity over time, 0–100. */
    harmony: number;
    /** Onset agreement, 0–100. */
    rhythm: number;
}
export interface Transcription {
    midi: ParsedMidi;
    analysis: AudioAnalysis;
    /** Score of the raw transcription, before any conversion to chip patterns. */
    quality: Quality;
    truncated: boolean;
}
export interface ScoredNote {
    start: number;
    end: number;
    pitch: number;
    velocity: number;
    drum: boolean;
}
/**
 * How much of a recording a list of notes keeps. Harmony compares pitch classes over time (the
 * notes are "rendered" as harmonic series, so octave slips and timbre are not punished); rhythm
 * compares onsets within 70 ms. An estimate for comparing settings, not a listening test.
 */
export declare function scoreNotes(analysis: AudioAnalysis, notes: readonly ScoredNote[]): Quality;
/** The notes a chip conversion actually plays, back in seconds, drums told apart by their voice. */
export declare function notesOfImport(conversion: MidiImport): ScoredNote[];
/** How a recording scores once converted to chip patterns: the number the import dialog shows. */
export declare function scoreImport(analysis: AudioAnalysis, conversion: MidiImport): Quality;
/**
 * What an 8 kHz, 8-bit, one-second sample keeps of a recording: the energy inside its length and
 * below 4 kHz. The 8-bit quantisation costs little on top at these levels and is not modelled.
 */
export declare function scoreSample(analysis: AudioAnalysis, seconds: number): Quality;
/**
 * The analysis alone, to score notes or a sample against a sound without transcribing it: short
 * effects and silence have nothing to transcribe but can still be measured.
 */
export declare function analyseAudio(channels: readonly Float32Array[], sampleRate: number, maxSeconds?: number): AudioAnalysis;
export declare function transcribe(channels: readonly Float32Array[], sampleRate: number, options?: TranscribeOptions): Transcription;
