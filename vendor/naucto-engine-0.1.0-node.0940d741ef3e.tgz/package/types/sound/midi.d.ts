/**
 * Standard MIDI File import into Naucto's native sound model.
 *
 * Self-contained on purpose: the same file is copied verbatim into the Naucto-AI service, which
 * converts generated MIDI with it, and a drift test there compares the two. Everything a MIDI file
 * can say that the chip cannot play is reported rather than silently approximated.
 */
export interface MidiNote {
    /** Start and end in seconds, after the tempo map. */
    start: number;
    end: number;
    /** The same places in beats (quarter notes) from the start, when the file says them. */
    startBeat?: number;
    endBeat?: number;
    pitch: number;
    velocity: number;
    channel: number;
}
export interface MidiTrack {
    index: number;
    name: string;
    notes: MidiNote[];
    channels: number[];
    program: number | null;
    percussion: boolean;
}
export interface ParsedMidi {
    tracks: MidiTrack[];
    /** Tempo in effect at the start, beats per minute. */
    bpm: number;
    tempoChanges: number;
    /**
     * The one tempo a performance played with a wavering pulse is best taken at, in beats a minute.
     *
     * Set only for a file with many small tempo changes — a recording of somebody playing, not a score
     * with a ritardando — where timing in seconds drifts off the bars and no phrase lands twice in the
     * same place. Notes are then placed by beat, so the music is as steady as it is written.
     */
    steadyBpm?: number;
    /** Notes whose release a sustain pedal held past their note-off. */
    sustained: number;
    warnings: string[];
    duration: number;
}
/** The instrument fields a conversion writes; the shape Naucto's `Instrument` has. */
export interface MidiInstrument {
    id: string;
    name: string;
    osc: 'square' | 'sine' | 'triangle' | 'saw' | 'noise';
    duty: number;
    detune: number;
    glide: number;
    env: {
        attack: number;
        decay: number;
        sustain: number;
        release: number;
    };
    vibrato: {
        rate: number;
        depth: number;
        delay: number;
    };
    arp: {
        rate: number;
    };
    filter: {
        type: 'off' | 'lp' | 'hp' | 'bp';
        cutoff: number;
        resonance: number;
        envAmount: number;
    };
    volume: number;
    pan: number;
    colour: number;
}
export interface MidiImportOptions {
    prefix: string;
    /** Voices the music may hold at once; one is usually left free for sound effects. */
    voices: number;
    /** Which tracks to import (all when omitted). */
    tracks?: number[];
    /** Instrument per track index; a default chip voice otherwise. */
    instruments?: Record<number, Omit<MidiInstrument, 'id'>>;
    /** `outer` keeps the highest and lowest notes of a chord (melody and bass) when voices run out. */
    strategy?: 'outer' | 'first';
    /** Tempo of the converted song; the file's opening tempo by default. */
    bpm?: number;
    /** First pattern slot to use; the caller picks free ones. */
    firstSlot?: number;
}
export interface MidiImportReport {
    sourceNotes: number;
    importedNotes: number;
    droppedNotes: number;
    quantizedNotes: number;
    percussionNotes: number;
    tempoChanges: number;
    sustainedNotes: number;
    peakVoices: number;
    voiceBudget: number;
    /** Places in the song's order list: how many sections the music is, repeats included. */
    sections: number;
    /** Sections that replay a pattern already stored instead of holding their notes again. */
    reusedSections: number;
    /** Steps in each pattern, chosen so the fewest notes have to be stored. */
    patternSteps: number;
    /** The finest timing the notes were snapped to, in steps: 1/8 keeps the file's own timing. */
    timingGrid: number;
    warnings: string[];
}
export interface MidiImport {
    instruments: MidiInstrument[];
    patterns: {
        id: string;
        slot: number;
        name: string;
        bpm: number;
        stepsPerBeat: 4;
        steps: number;
        notes: {
            step: number;
            pitch: number;
            length: number;
            instrument: string;
            volume: number;
        }[];
    }[];
    song: {
        name: string;
        sequence: string[];
        loop: boolean;
        loopStart: number;
    };
    report: MidiImportReport;
}
export declare function drumPitch(key: number): number;
export declare function readMidi(bytes: Uint8Array): ParsedMidi;
export declare function chipInstrument(name: string, percussion: boolean): Omit<MidiInstrument, 'id'>;
export declare function convertMidi(parsed: ParsedMidi, options: MidiImportOptions): MidiImport;
/**
 * A Standard MIDI File (format 1, 480 ticks a beat) of parsed notes, so a transcription can be
 * taken to another tool. One track per `MidiTrack`, at the opening tempo.
 */
export declare function writeMidi(parsed: ParsedMidi): Uint8Array;
