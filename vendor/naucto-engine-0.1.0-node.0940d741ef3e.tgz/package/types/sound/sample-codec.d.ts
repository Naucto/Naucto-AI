/**
 * PCM samples live in the game document as base64 of signed 8-bit mono at {@link SAMPLE_RATE}.
 *
 * 8-bit is the console's own resolution and keeps a sample inside {@link MAX_SAMPLE_BYTES} without
 * a compressor: at 8 kHz that is a full second of audio, which is what a kick, a coin or a jump
 * actually needs. Yjs stores it as a string, so the encoding has to be text.
 */
export declare const SAMPLE_RATE = 8000;
/** How many audio seconds fit in the budget. */
export declare const MAX_SAMPLE_SECONDS: number;
/**
 * Mono-mix, resample and clamp arbitrary decoded audio down to what a sample may be.
 *
 * Nearest-neighbour resampling on purpose: the target rate is low enough that interpolation
 * mostly smears the aliasing the console is supposed to have.
 */
export declare function toSampleBytes(channels: readonly Float32Array[], sourceRate: number, maxBytes?: number): Int8Array;
/** Base64 of the raw bytes — what goes into `game.samples`. */
export declare function encodeSample(pcm: Int8Array): string;
/** Back to the -1..1 floats the synth renders. Returns an empty buffer for anything unreadable. */
export declare function decodeSample(base64: string): Float32Array;
