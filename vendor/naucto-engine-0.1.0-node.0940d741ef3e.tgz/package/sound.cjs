"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/sound.ts
var sound_exports = {};
__export(sound_exports, {
  ANALYSIS_RATE: () => ANALYSIS_RATE,
  MAX_SAMPLE_BYTES: () => MAX_SAMPLE_BYTES,
  MAX_SAMPLE_SECONDS: () => MAX_SAMPLE_SECONDS,
  NOTE_NAMES: () => NOTE_NAMES,
  SAMPLE_RATE: () => SAMPLE_RATE,
  SONG_SLOTS: () => SONG_SLOTS,
  SUBSTEPS: () => SUBSTEPS,
  Sequencer: () => Sequencer,
  SynthCore: () => SynthCore,
  VOICES: () => VOICES,
  analyseAudio: () => analyseAudio,
  chipInstrument: () => chipInstrument,
  convertMidi: () => convertMidi,
  decodeSample: () => decodeSample,
  defaultInstrument: () => defaultInstrument,
  defaultPattern: () => defaultPattern,
  defaultSong: () => defaultSong,
  drumPitch: () => drumPitch,
  encodeSample: () => encodeSample,
  midiToFrequency: () => midiToFrequency,
  midiToNoteName: () => midiToNoteName,
  noteNameToMidi: () => noteNameToMidi,
  notesOfImport: () => notesOfImport,
  readMidi: () => readMidi,
  scoreImport: () => scoreImport,
  scoreNotes: () => scoreNotes,
  scoreSample: () => scoreSample,
  toSampleBytes: () => toSampleBytes,
  transcribe: () => transcribe,
  writeMidi: () => writeMidi
});
module.exports = __toCommonJS(sound_exports);

// src/sound/midi.ts
var MAX_BYTES = 262144;
var MAX_EVENTS = 5e4;
var MAX_SECONDS = 600;
var PATTERN_SIZES = [32, 16, 64];
var PATTERN_OVERHEAD = 4;
var EXACT_GRID = 0.125;
var TIDY_GRIDS = [1, 0.5, 0.25];
var TIDY_GAIN = 0.85;
var TIDY_SHIFT = 0.2;
var VOLUME_TOLERANCE = 0.15;
var RELEASE_SECONDS = 0.02;
var WAVERING_CHANGES = 8;
var WAVERING_SPREAD = 1.5;
var DRUMS = [
  [[35, 36], 28],
  [[37, 38, 39, 40], 52],
  [[41, 43, 45, 47], 44],
  [[48, 50], 56],
  [[42, 44], 84],
  [[46], 80],
  [[49, 51, 52, 55, 57, 59], 96]
];
function drumPitch(key) {
  return DRUMS.find(([keys]) => keys.includes(key))?.[1] ?? 64;
}
function readMidi(bytes) {
  if (bytes.length > MAX_BYTES) throw new Error("MIDI exceeds 256 KiB");
  let offset = 0;
  const byte = () => {
    if (offset >= bytes.length) throw new Error("Truncated MIDI");
    return bytes[offset++] ?? 0;
  };
  const word = () => byte() * 256 + byte();
  const dword = () => word() * 65536 + word();
  const tag = () => String.fromCharCode(byte(), byte(), byte(), byte());
  const vlq = () => {
    let result = 0;
    for (let i = 0; i < 4; i++) {
      const b = byte();
      result = result * 128 + (b & 127);
      if (!(b & 128)) return result;
    }
    throw new Error("Invalid MIDI variable-length quantity");
  };
  if (tag() !== "MThd" || dword() !== 6) throw new Error("Invalid MIDI header");
  const format = word();
  const count = word();
  const ppq = word();
  if (format > 1 || count < 1 || count > 64 || !ppq || ppq & 32768 || format === 0 && count !== 1)
    throw new Error("Only format 0/1 files with metrical timing are supported");
  const warnings = /* @__PURE__ */ new Set();
  const tempos = [];
  const raw = [];
  let events = 0;
  for (let track = 0; track < count; track++) {
    if (tag() !== "MTrk") throw new Error("Expected MIDI track");
    const length = dword();
    const end = offset + length;
    if (end > bytes.length) throw new Error("Truncated MIDI track");
    let tick = 0;
    let running = 0;
    const active = /* @__PURE__ */ new Map();
    const pedal = /* @__PURE__ */ new Map();
    const held = /* @__PURE__ */ new Map();
    const out = {
      name: "",
      notes: [],
      channels: /* @__PURE__ */ new Set(),
      program: null
    };
    while (offset < end) {
      if (++events > MAX_EVENTS) throw new Error("Too many MIDI events");
      tick += vlq();
      let status = byte();
      if (status < 128) {
        if (!running) throw new Error("Invalid MIDI running status");
        offset--;
        status = running;
      } else if (status < 240) running = status;
      else running = 0;
      if (status === 255) {
        const type = byte();
        const size = vlq();
        const next = offset + size;
        if (next > end) throw new Error("Truncated MIDI metadata");
        if (type === 81 && size === 3) {
          const us = byte() * 65536 + byte() * 256 + byte();
          if (!us) throw new Error("Invalid tempo");
          tempos.push({ tick, us });
        } else if (type === 3 && !out.name) {
          out.name = String.fromCharCode(...bytes.subarray(offset, Math.min(next, offset + 40)));
        }
        offset = next;
        if (type === 47) {
          offset = end;
          break;
        }
      } else if (status === 240 || status === 247) {
        offset += vlq();
        warnings.add("System-exclusive messages were omitted.");
      } else {
        const kind = status >> 4;
        const channel = status & 15;
        const a = byte();
        const b = kind === 12 || kind === 13 ? 0 : byte();
        if (a > 127 || b > 127) throw new Error("Invalid MIDI data byte");
        const key = `${String(channel)}:${String(a)}`;
        if (kind === 9 && b > 0) {
          const list = active.get(key) ?? [];
          list.push({ tick, velocity: b });
          active.set(key, list);
          out.channels.add(channel);
        } else if (kind === 8 || kind === 9 && b === 0) {
          const start = active.get(key)?.shift();
          if (!start) continue;
          const note = { tick: start.tick, end: tick, pitch: a, velocity: start.velocity, channel };
          if (pedal.get(channel) && channel !== 9)
            held.set(channel, [...held.get(channel) ?? [], note]);
          else out.notes.push(note);
        } else if (kind === 11 && a === 64) {
          const down = b >= 64;
          if (!down && pedal.get(channel)) {
            for (const note of held.get(channel) ?? [])
              out.notes.push({ ...note, end: tick, sustained: true });
            held.delete(channel);
          }
          pedal.set(channel, down);
        } else if (kind === 11) warnings.add("Controllers other than sustain were omitted.");
        else if (kind === 12) out.program ??= a;
        else if (kind === 14) warnings.add("Pitch bends were omitted.");
        else if (kind === 10 || kind === 13) warnings.add("Aftertouch was omitted.");
      }
      if (offset > end) throw new Error("Event crosses its track boundary");
    }
    if ([...active.values()].some((list) => list.length))
      throw new Error("Unterminated MIDI notes");
    for (const list of held.values())
      for (const note of list) out.notes.push({ ...note, end: tick, sustained: true });
    raw.push(out);
  }
  if (offset !== bytes.length) throw new Error("Unexpected trailing MIDI data");
  tempos.sort((x, y) => x.tick - y.tick);
  const map = [
    { tick: 0, us: tempos[0]?.tick === 0 ? tempos[0].us : 5e5, seconds: 0 }
  ];
  for (const tempo of tempos) {
    const last = map[map.length - 1];
    if (!last || tempo.tick === 0) continue;
    if (tempo.us === last.us) continue;
    map.push({
      tick: tempo.tick,
      us: tempo.us,
      seconds: last.seconds + (tempo.tick - last.tick) * last.us / ppq / 1e6
    });
  }
  const seconds = (tick) => {
    let at = map[0] ?? { tick: 0, us: 5e5, seconds: 0 };
    for (const entry of map) if (entry.tick <= tick) at = entry;
    return at.seconds + (tick - at.tick) * at.us / ppq / 1e6;
  };
  let sustained = 0;
  let duration = 0;
  const tracks = raw.map((track, index) => {
    const notes = track.notes.map((note) => {
      if (note.sustained) sustained++;
      const n = {
        start: seconds(note.tick),
        end: seconds(note.end),
        startBeat: note.tick / ppq,
        endBeat: note.end / ppq,
        pitch: note.pitch,
        velocity: note.velocity,
        channel: note.channel
      };
      duration = Math.max(duration, n.end);
      return n;
    });
    return {
      index,
      name: track.name.replace(/[^\x20-\x7e]/g, "").trim() || `track ${String(index + 1)}`,
      notes,
      channels: [...track.channels].sort((x, y) => x - y),
      program: track.program,
      percussion: track.channels.size > 0 && [...track.channels].every((c) => c === 9)
    };
  });
  if (duration > MAX_SECONDS) throw new Error("MIDI is longer than ten minutes");
  if (!tracks.some((t) => t.notes.length)) throw new Error("MIDI contains no completed notes");
  const speeds = map.map((entry) => entry.us);
  const wavering = map.length > WAVERING_CHANGES && Math.max(...speeds) / Math.min(...speeds) <= WAVERING_SPREAD;
  let steadyBpm;
  if (wavering && duration > 0) {
    const beats = Math.max(...tracks.flatMap((t) => t.notes.map((n) => n.endBeat ?? 0)));
    steadyBpm = 60 * beats / duration;
    warnings.add(
      `${String(map.length - 1)} small tempo changes were evened out to one steady tempo, so repeated phrases line up.`
    );
  } else if (map.length > 1)
    warnings.add(
      `${String(map.length - 1)} tempo change(s) were flattened: timing is kept, the song plays at one tempo.`
    );
  return {
    tracks,
    bpm: 6e7 / (map[0]?.us ?? 5e5),
    ...steadyBpm === void 0 ? {} : { steadyBpm },
    tempoChanges: map.length - 1,
    sustained,
    warnings: [...warnings],
    duration
  };
}
function chipInstrument(name, percussion) {
  return {
    name,
    osc: percussion ? "noise" : "square",
    duty: 0.5,
    detune: 0,
    glide: 0,
    env: percussion ? { attack: 1e-3, decay: 0.08, sustain: 0, release: 0.02 } : { attack: 2e-3, decay: 0.05, sustain: 0.6, release: 0.05 },
    vibrato: { rate: 0, depth: 0, delay: 0 },
    arp: { rate: 0 },
    filter: { type: "off", cutoff: 8e3, resonance: 0, envAmount: 0 },
    volume: percussion ? 0.5 : 0.4,
    pan: 0,
    colour: percussion ? 2 : 4
  };
}
function dedupeSections(sections, steps) {
  const seen = /* @__PURE__ */ new Map();
  const patterns = [];
  const order = [];
  for (const section of sections) {
    const relative = [...section].sort(
      (a, b) => a.step - b.step || a.pitch - b.pitch || a.instrument.localeCompare(b.instrument)
    );
    const key = relative.map((n) => `${String(n.step)}|${String(n.pitch)}|${String(n.length)}|${n.instrument}`).join(";");
    const alike = (seen.get(key) ?? []).find(
      (candidate) => (patterns[candidate] ?? []).every(
        (n, i) => Math.abs(n.volume - (relative[i]?.volume ?? 0)) <= VOLUME_TOLERANCE
      )
    );
    let slot = alike;
    if (slot === void 0) {
      slot = patterns.length;
      seen.set(key, [...seen.get(key) ?? [], slot]);
      patterns.push(relative);
    }
    order.push(slot);
  }
  const cost = patterns.reduce((sum, p) => sum + p.length + PATTERN_OVERHEAD, 0);
  return { steps, patterns, order, cost };
}
function convertMidi(parsed, options) {
  const voices = options.voices;
  if (!Number.isInteger(voices) || voices < 1 || voices > 5)
    throw new Error("Voice budget must be 1\u20135");
  if (!/^[a-zA-Z0-9_-]{1,40}$/.test(options.prefix)) throw new Error("Invalid prefix");
  const steady = parsed.steadyBpm !== void 0;
  const bpm = Math.round(options.bpm ?? parsed.steadyBpm ?? parsed.bpm);
  if (bpm < 40 || bpm > 240) throw new Error("Tempo is outside the editor range (40\u2013240 BPM)");
  const chosen = parsed.tracks.filter(
    (t) => t.notes.length && (!options.tracks || options.tracks.includes(t.index))
  );
  if (!chosen.length) throw new Error("Choose at least one track with notes");
  const stepsPerSecond = bpm / 60 * 4;
  const release = RELEASE_SECONDS * stepsPerSecond;
  const instruments = [];
  let percussionNotes = 0;
  const sources = [];
  for (const track of chosen) {
    const id = `${options.prefix}-t${String(track.index)}`;
    instruments.push({
      ...options.instruments?.[track.index] ?? chipInstrument(track.name.slice(0, 40), track.percussion),
      id
    });
    for (const note of track.notes) {
      const drum = note.channel === 9;
      if (drum) percussionNotes++;
      sources.push({
        // By beat for a pulse that wavers, so a bar is the same length every time it comes round.
        start: steady && note.startBeat !== void 0 ? note.startBeat * 4 : note.start * stepsPerSecond,
        end: steady && note.endBeat !== void 0 ? note.endBeat * 4 : note.end * stepsPerSecond,
        pitch: drum ? drumPitch(note.pitch) : note.pitch,
        volume: note.velocity / 127,
        instrument: id
      });
    }
  }
  const attempt = (grid) => {
    const per = 1 / grid;
    let quantized2 = 0;
    let shift = 0;
    const candidates = sources.map((source) => {
      const step = Math.round(source.start * per) / per;
      const end = Math.max(step + grid, Math.round(source.end * per) / per);
      if (Math.abs(step - source.start) > 1e-6 || Math.abs(end - source.end) > 1e-6) quantized2++;
      shift += Math.abs(step - source.start);
      return {
        step,
        length: end - step,
        pitch: source.pitch,
        volume: source.volume,
        instrument: source.instrument
      };
    });
    candidates.sort((a, b) => a.step - b.step || b.pitch - a.pitch);
    if (!candidates.length) throw new Error("No notes fit the voice budget");
    const total = Math.max(...candidates.map((n) => n.step + n.length));
    const allocate = (list, held) => {
      const accepted2 = [];
      let ends = held;
      let dropped2 = 0;
      let peak2 = 0;
      for (let i = 0; i < list.length; ) {
        const step = list[i]?.step ?? 0;
        const batch = [];
        for (let next = list[i]; next?.step === step; next = list[++i]) batch.push(next);
        ends = ends.filter((end) => end > step);
        const free = voices - ends.length;
        let keep = batch;
        if (batch.length > free) {
          if (options.strategy === "first") keep = batch.slice(0, Math.max(0, free));
          else {
            const byPitch = [...batch].sort((a, b) => b.pitch - a.pitch);
            const ordered = [
              byPitch[0],
              byPitch[byPitch.length - 1],
              ...byPitch.slice(1, -1).sort((a, b) => b.volume - a.volume)
            ];
            keep = [...new Set(ordered.filter((n) => !!n))].slice(
              0,
              Math.max(0, free)
            );
          }
          dropped2 += batch.length - keep.length;
        }
        for (const note of keep) {
          accepted2.push(note);
          ends.push(note.step + note.length + release);
        }
        peak2 = Math.max(peak2, ends.length);
      }
      return { accepted: accepted2, dropped: dropped2, peak: peak2, ends };
    };
    let best = null;
    for (const steps of PATTERN_SIZES) {
      const count = Math.ceil(total / steps);
      const sections = Array.from({ length: count }, () => []);
      for (const note of candidates) sections[Math.floor(note.step / steps)]?.push(note);
      const heard = [];
      const seenRaw = /* @__PURE__ */ new Map();
      const kept = [];
      const accepted2 = [];
      let ends = [];
      let dropped2 = 0;
      let peak2 = 0;
      for (const [index, section] of sections.entries()) {
        const base = index * steps;
        const raw = section.map((n) => ({ ...n, step: n.step - base }));
        const key = raw.map((n) => `${String(n.step)}|${String(n.pitch)}|${String(n.length)}|${n.instrument}`).join(";");
        ends = ends.filter((end) => end > base);
        const known = (seenRaw.get(key) ?? []).map((i) => heard[i]).find(
          (h) => h?.raw.every((n, i) => Math.abs(n.volume - (raw[i]?.volume ?? 0)) <= VOLUME_TOLERANCE)
        );
        let result;
        if (known) {
          result = known;
          for (const n of known.kept) ends.push(base + n.step + n.length + release);
          peak2 = Math.max(peak2, ends.length);
        } else {
          const out = allocate(section, ends);
          ends = out.ends;
          peak2 = Math.max(peak2, out.peak);
          result = {
            kept: out.accepted.map((n) => ({ ...n, step: n.step - base })),
            dropped: out.dropped
          };
          seenRaw.set(key, [...seenRaw.get(key) ?? [], heard.length]);
          heard.push({ raw, ...result });
        }
        dropped2 += result.dropped;
        kept.push(result.kept);
        for (const n of result.kept) accepted2.push({ ...n, step: n.step + base });
      }
      const packed2 = dedupeSections(kept, steps);
      if (!best || packed2.cost < best.packed.cost)
        best = {
          grid,
          accepted: accepted2,
          dropped: dropped2,
          peak: peak2,
          quantized: quantized2,
          meanShift: sources.length ? shift / sources.length : 0,
          packed: packed2
        };
    }
    if (!best?.accepted.length) throw new Error("No notes fit the voice budget");
    return best;
  };
  const exact = attempt(EXACT_GRID);
  let chosenAttempt = exact;
  for (const grid of TIDY_GRIDS) {
    const tidy = attempt(grid);
    const smaller = tidy.packed.cost <= exact.packed.cost * TIDY_GAIN;
    const close = tidy.meanShift <= TIDY_SHIFT;
    const whole = tidy.accepted.length >= exact.accepted.length * 0.98;
    if (smaller && close && whole && tidy.packed.cost < chosenAttempt.packed.cost)
      chosenAttempt = tidy;
  }
  const { accepted, dropped, peak, quantized, packed } = chosenAttempt;
  const first = options.firstSlot ?? 0;
  const patterns = packed.patterns.map((notes, index) => ({
    id: `${options.prefix}-p${String(index)}`,
    slot: first + index,
    name: `${options.prefix} ${String(index + 1)}`,
    bpm,
    stepsPerBeat: 4,
    steps: packed.steps,
    notes
  }));
  const warnings = [...parsed.warnings];
  if (percussionNotes)
    warnings.push("Percussion was mapped onto a noise voice; tune its pitches by ear.");
  if (parsed.sustained)
    warnings.push(`${String(parsed.sustained)} note(s) held by the sustain pedal were lengthened.`);
  if (chosen.some((t) => t.program !== null && !options.instruments?.[t.index]))
    warnings.push(
      "General MIDI programs were replaced by chip voices; choose instruments before importing."
    );
  return {
    instruments,
    patterns,
    song: {
      name: options.prefix,
      sequence: packed.order.map((index) => patterns[index]?.id ?? ""),
      loop: true,
      loopStart: 0
    },
    report: {
      sourceNotes: chosen.reduce((sum, t) => sum + t.notes.length, 0),
      importedNotes: accepted.length,
      droppedNotes: dropped,
      quantizedNotes: quantized,
      percussionNotes,
      tempoChanges: parsed.tempoChanges,
      sustainedNotes: parsed.sustained,
      peakVoices: peak,
      voiceBudget: voices,
      sections: packed.order.length,
      reusedSections: packed.order.length - patterns.length,
      patternSteps: packed.steps,
      timingGrid: chosenAttempt.grid,
      warnings
    }
  };
}
function writeMidi(parsed) {
  const ppq = 480;
  const ticksPerSecond = parsed.bpm / 60 * ppq;
  const vlq = (value) => {
    const out = [value & 127];
    for (let v = value >> 7; v > 0; v >>= 7) out.unshift(v & 127 | 128);
    return out;
  };
  const chunk = (tag, body) => [
    ...Array.from(tag, (c) => c.charCodeAt(0)),
    body.length >>> 24 & 255,
    body.length >>> 16 & 255,
    body.length >>> 8 & 255,
    body.length & 255,
    ...body
  ];
  const us = Math.round(6e7 / parsed.bpm);
  const tempo = [0, 255, 81, 3, us >> 16 & 255, us >> 8 & 255, us & 255, 0, 255, 47, 0];
  const tracks = parsed.tracks.map((track) => {
    const events = [];
    for (const note of track.notes) {
      const channel = note.channel & 15;
      const pitch = Math.max(0, Math.min(127, Math.round(note.pitch)));
      const velocity = Math.max(1, Math.min(127, Math.round(note.velocity)));
      events.push({
        tick: Math.round(note.start * ticksPerSecond),
        order: 1,
        bytes: [144 | channel, pitch, velocity]
      });
      events.push({
        tick: Math.max(
          Math.round(note.start * ticksPerSecond) + 1,
          Math.round(note.end * ticksPerSecond)
        ),
        order: 0,
        bytes: [128 | channel, pitch, 0]
      });
    }
    events.sort((a, b) => a.tick - b.tick || a.order - b.order);
    const body = [];
    const name = Array.from(track.name.slice(0, 40), (c) => c.charCodeAt(0) & 127);
    body.push(0, 255, 3, name.length, ...name);
    if (track.program !== null && track.channels[0] !== void 0)
      body.push(0, 192 | track.channels[0] & 15, track.program & 127);
    let at = 0;
    for (const event of events) {
      body.push(...vlq(event.tick - at), ...event.bytes);
      at = event.tick;
    }
    body.push(0, 255, 47, 0);
    return chunk("MTrk", body);
  });
  const header = chunk("MThd", [0, 1, 0, tracks.length + 1, ppq >> 8, ppq & 255]);
  return Uint8Array.from([...header, ...chunk("MTrk", tempo), ...tracks.flat()]);
}

// src/sound/model.ts
var SUBSTEPS = 8;
var VOICES = 5;
var SONG_SLOTS = 16;
var MAX_SAMPLE_BYTES = 8 * 1024;
var NOTE_NAMES = [
  "C",
  "C#",
  "D",
  "D#",
  "E",
  "F",
  "F#",
  "G",
  "G#",
  "A",
  "A#",
  "B"
];
var midiToFrequency = (midi) => 440 * Math.pow(2, (midi - 69) / 12);
var noteNameToMidi = (name) => {
  const m = /^([A-Ga-g])([#b]?)(-?\d+)$/.exec(name.trim());
  if (!m) return null;
  const base = { c: 0, d: 2, e: 4, f: 5, g: 7, a: 9, b: 11 }[(m[1] ?? "c").toLowerCase()] ?? 0;
  const acc = m[2] === "#" ? 1 : m[2] === "b" ? -1 : 0;
  return (Number(m[3]) + 1) * 12 + base + acc;
};
var midiToNoteName = (midi) => `${NOTE_NAMES[(midi % 12 + 12) % 12] ?? "C"}${String(Math.floor(midi / 12) - 1)}`;
var defaultInstrument = (id, name = "lead") => ({
  id,
  name,
  osc: "square",
  duty: 0.5,
  detune: 0,
  glide: 0,
  env: { attack: 0.01, decay: 0.1, sustain: 0.6, release: 0.15 },
  vibrato: { rate: 5, depth: 0, delay: 0.2 },
  arp: { rate: 0 },
  filter: { type: "off", cutoff: 8e3, resonance: 0.2, envAmount: 0 },
  volume: 0.8,
  pan: 0,
  colour: 4
});
var defaultPattern = (id, slot = 0, name = "pattern 00") => ({
  id,
  slot,
  name,
  bpm: 124,
  stepsPerBeat: 4,
  steps: 32,
  notes: []
});
var defaultSong = () => ({
  name: "",
  sequence: [],
  loop: true,
  loopStart: 0
});

// src/sound/sample-codec.ts
var SAMPLE_RATE = 8e3;
var MAX_SAMPLE_SECONDS = MAX_SAMPLE_BYTES / SAMPLE_RATE;
function toSampleBytes(channels, sourceRate, maxBytes = MAX_SAMPLE_BYTES) {
  const first = channels[0];
  if (!first || sourceRate <= 0) return new Int8Array(0);
  const ratio = SAMPLE_RATE / sourceRate;
  const wanted = Math.floor(first.length * ratio);
  const length = Math.min(wanted, maxBytes);
  const out = new Int8Array(length);
  for (let i = 0; i < length; i++) {
    const src = Math.floor(i / ratio);
    let sum = 0;
    for (const channel of channels) sum += channel[src] ?? 0;
    const mixed = sum / channels.length;
    out[i] = Math.max(-127, Math.min(127, Math.round(mixed * 127)));
  }
  return out;
}
function encodeSample(pcm) {
  let binary = "";
  const bytes = new Uint8Array(pcm.buffer, pcm.byteOffset, pcm.byteLength);
  for (let i = 0; i < bytes.length; i += 1024) {
    binary += String.fromCharCode(...bytes.subarray(i, i + 1024));
  }
  return btoa(binary);
}
function decodeSample(base64) {
  let binary;
  try {
    binary = atob(base64);
  } catch {
    return new Float32Array(0);
  }
  const out = new Float32Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    const byte = binary.charCodeAt(i);
    out[i] = (byte > 127 ? byte - 256 : byte) / 127;
  }
  return out;
}

// src/sound/Sequencer.ts
var Sequencer = class {
  constructor(synth, sampleRate) {
    this.synth = synth;
    this.sampleRate = sampleRate;
  }
  synth;
  sampleRate;
  song = null;
  patterns = /* @__PURE__ */ new Map();
  instruments = /* @__PURE__ */ new Map();
  seqIndex = 0;
  /** Position in the current pattern, counted in sub-steps rather than steps. */
  subStep = 0;
  samplesToNextSubStep = 0;
  playing = false;
  fade = 1;
  fadeRate = 0;
  fadeTarget = 1;
  stopWhenFaded = false;
  sfx = [];
  setLibrary(instruments, patterns) {
    this.instruments = instruments;
    this.patterns = patterns;
  }
  /** `from` is where in the first pattern to begin, in steps; the clock rounds it onto its lattice. */
  playSong(song, loop, fadeIn, from = 0) {
    this.song = { ...song, loop };
    this.seqIndex = 0;
    this.subStep = Math.max(0, Math.round(from * SUBSTEPS));
    this.samplesToNextSubStep = 0;
    this.playing = song.sequence.length > 0;
    this.fade = fadeIn > 0 ? 0 : 1;
    this.fadeTarget = 1;
    this.fadeRate = fadeIn > 0 ? 1 / (fadeIn * this.sampleRate) : 0;
    this.stopWhenFaded = false;
    this.synth.musicGain = this.fade;
  }
  /**
   * Whether what is playing carries on past its last pattern.
   *
   * Asked mid-take: the chain was handed over with its own answer when playback started, and
   * without this the box could be unticked to no effect until the next start.
   */
  setLoop(loop) {
    if (this.song) this.song = { ...this.song, loop };
  }
  stopMusic(fadeOut) {
    if (!this.playing) return;
    if (fadeOut <= 0) {
      this.playing = false;
      this.song = null;
      this.releaseMusicVoices();
      return;
    }
    this.fadeTarget = 0;
    this.fadeRate = 1 / (fadeOut * this.sampleRate);
    this.stopWhenFaded = true;
  }
  playSfx(pattern, pitchOffset, volume, channel) {
    this.sfx.push({ pattern, subStep: 0, samplesToNext: 0, pitchOffset, volume, channel });
  }
  stopAll() {
    this.playing = false;
    this.song = null;
    this.sfx.length = 0;
    this.synth.stopAll();
  }
  /**
   * The sub-step that is sounding, in steps and fractions of one: finer than any note position,
   * which is what a playhead has to follow to move rather than jump.
   *
   * The counter is one ahead of what is heard, since a sub-step is triggered and then counted, so
   * this reports the one before it. Whole steps are where notes sit, and a caller wanting the step
   * a note is playing on takes the floor: the fraction is how far that step has run.
   */
  position() {
    if (!this.playing) return null;
    return { pattern: this.seqIndex, step: Math.max(0, this.subStep - 1) / SUBSTEPS };
  }
  get isPlaying() {
    return this.playing;
  }
  /** Advance the clock by `frames` samples, triggering notes that fall inside. */
  advance(frames) {
    if (this.fadeRate > 0 && this.fade !== this.fadeTarget) {
      this.fade += Math.sign(this.fadeTarget - this.fade) * this.fadeRate * frames;
      this.fade = Math.max(0, Math.min(1, this.fade));
      this.synth.musicGain = this.fade;
      if (this.fade === this.fadeTarget && this.stopWhenFaded) {
        this.playing = false;
        this.song = null;
        this.releaseMusicVoices();
        this.synth.musicGain = 1;
      }
    }
    if (this.playing && this.song) this.advanceSong(frames);
    for (let i = this.sfx.length - 1; i >= 0; i--) {
      const lane = this.sfx[i];
      if (!lane) continue;
      let left = frames;
      while (left > 0) {
        if (lane.samplesToNext <= 0) {
          if (lane.subStep >= lane.pattern.steps * SUBSTEPS) {
            this.sfx.splice(i, 1);
            break;
          }
          this.triggerSubStep(
            lane.pattern,
            lane.subStep,
            lane.pitchOffset,
            lane.volume,
            1,
            lane.channel
          );
          lane.samplesToNext = this.subStepSamples(lane.pattern, lane.subStep);
          lane.subStep++;
        }
        const consume = Math.min(left, lane.samplesToNext);
        lane.samplesToNext -= consume;
        left -= consume;
      }
    }
  }
  advanceSong(frames) {
    const song = this.song;
    if (!song) return;
    let left = frames;
    while (left > 0 && this.playing) {
      const entry = song.sequence[this.seqIndex] ?? null;
      if (entry === null) {
        this.playing = false;
        this.song = null;
        return;
      }
      const pattern = this.patterns.get(entry);
      if (!pattern) {
        if (!this.nextPattern(song)) return;
        continue;
      }
      if (this.samplesToNextSubStep <= 0) {
        if (this.subStep >= pattern.steps * SUBSTEPS) {
          if (!this.nextPattern(song)) return;
          continue;
        }
        this.triggerSubStep(pattern, this.subStep, 0, 1, 0);
        this.samplesToNextSubStep = this.subStepSamples(pattern, this.subStep);
        this.subStep++;
      }
      const consume = Math.min(left, this.samplesToNextSubStep);
      this.samplesToNextSubStep -= consume;
      left -= consume;
    }
  }
  nextPattern(song) {
    this.seqIndex++;
    this.subStep = 0;
    if (this.seqIndex >= song.sequence.length) {
      if (!song.loop) {
        this.playing = false;
        this.song = null;
        return false;
      }
      this.seqIndex = Math.min(song.loopStart, song.sequence.length - 1);
    }
    return true;
  }
  stepSamples(p) {
    return Math.max(1, Math.round(60 / p.bpm / p.stepsPerBeat * this.sampleRate));
  }
  /**
   * Samples from one sub-step to the next, spread so that the sub-steps of a step add up to exactly
   * the samples that step has always taken. A whole step therefore still falls on the sample it
   * used to; only the positions between two of them are new.
   */
  subStepSamples(p, subStep) {
    const step = this.stepSamples(p);
    const base = Math.floor(step / SUBSTEPS);
    const spread = step - base * SUBSTEPS;
    return base + (subStep % SUBSTEPS < spread ? 1 : 0);
  }
  triggerSubStep(p, subStep, pitchOffset, volume, priority, channel) {
    const secondsPerStep = 60 / p.bpm / p.stepsPerBeat;
    const byInstrument = /* @__PURE__ */ new Map();
    for (const n of p.notes) {
      if (Math.round(n.step * SUBSTEPS) !== subStep) continue;
      const held = byInstrument.get(n.instrument);
      if (held) held.push(n);
      else byInstrument.set(n.instrument, [n]);
    }
    for (const [id, notes] of byInstrument) {
      const ins = this.instruments.get(id);
      if (!ins) continue;
      if (ins.arp.rate > 0 && notes.length > 1) {
        const chord = [...notes].sort((a, b) => a.pitch - b.pitch);
        const root = chord[0];
        if (!root) continue;
        this.synth.noteOn(
          ins,
          root.pitch + pitchOffset,
          Math.max(...notes.map((n) => n.volume)) * volume,
          Math.max(...notes.map((n) => n.length)) * secondsPerStep,
          channel,
          priority,
          chord.map((n) => n.pitch - root.pitch)
        );
        continue;
      }
      for (const n of notes) {
        this.synth.noteOn(
          ins,
          n.pitch + pitchOffset,
          n.volume * volume,
          n.length * secondsPerStep,
          channel,
          priority
        );
      }
    }
  }
  releaseMusicVoices() {
    this.synth.voices.forEach((v, i) => {
      if (v.active && v.priority === 0) this.synth.noteOff(i);
    });
  }
};

// src/sound/SynthCore.ts
var newVoice = () => ({
  active: false,
  instrument: null,
  pitch: 60,
  freq: 261.63,
  curFreq: 261.63,
  phase: 0,
  age: 0,
  stage: 4,
  env: 0,
  releaseAt: -1,
  releaseFrom: 0,
  velocity: 1,
  noiseSeed: 4660,
  lastNoise: 0,
  low: 0,
  band: 0,
  sample: null,
  samplePos: 0,
  priority: 0,
  arp: []
});
var SynthCore = class {
  constructor(sampleRate) {
    this.sampleRate = sampleRate;
  }
  sampleRate;
  voices = Array.from({ length: VOICES }, newVoice);
  samples = /* @__PURE__ */ new Map();
  master = 1;
  /** The song's fade; `musicLevel` is the volume the game asks for. Both scale the music. */
  musicGain = 1;
  musicLevel = 1;
  sfxGain = 1;
  /** Start a note; returns the voice index used. `channel` forces a voice. */
  noteOn(instrument, pitch, velocity, lengthSeconds, channel, priority = 0, arp = []) {
    const idx = channel !== void 0 ? Math.max(0, Math.min(VOICES - 1, channel)) : this.allocate(priority);
    const v = this.voices[idx];
    if (!v) return idx;
    const wasSounding = v.active && v.stage !== 4;
    v.active = true;
    v.instrument = instrument;
    v.pitch = pitch;
    v.freq = midiToFrequency(pitch);
    v.curFreq = instrument.glide > 0 && wasSounding ? v.curFreq : v.freq;
    v.phase = 0;
    v.age = 0;
    v.stage = 0;
    v.env = 0;
    v.velocity = Math.max(0, Math.min(1, velocity));
    v.releaseAt = lengthSeconds > 0 ? Math.round(lengthSeconds * this.sampleRate) : -1;
    v.low = 0;
    v.band = 0;
    v.priority = priority;
    v.arp = arp;
    v.sample = instrument.osc === "sample" && instrument.sampleId ? this.samples.get(instrument.sampleId) ?? null : null;
    v.samplePos = 0;
    return idx;
  }
  noteOff(channel) {
    const v = this.voices[channel];
    if (v?.active && v.stage < 3) this.release(v);
  }
  stopAll() {
    for (const v of this.voices) {
      v.active = false;
      v.stage = 4;
    }
  }
  isPlaying(channel) {
    return this.voices[channel]?.active ?? false;
  }
  /** Render `frames` stereo samples into out[0] (left) and out[1] (right). */
  render(outL, outR, frames) {
    outL.fill(0, 0, frames);
    outR.fill(0, 0, frames);
    for (const v of this.voices) {
      if (!v.active || !v.instrument) continue;
      this.renderVoice(v, outL, outR, frames);
    }
    for (let i = 0; i < frames; i++) {
      outL[i] = softClip((outL[i] ?? 0) * this.master);
      outR[i] = softClip((outR[i] ?? 0) * this.master);
    }
  }
  allocate(priority) {
    let free = this.voices.findIndex((v) => !v.active);
    if (free !== -1) return free;
    void priority;
    free = 0;
    let best = Infinity;
    this.voices.forEach((v, i) => {
      const score = v.priority * 1e9 - v.age;
      if (score < best) {
        best = score;
        free = i;
      }
    });
    return free;
  }
  release(v) {
    v.stage = 3;
    v.releaseFrom = v.env;
    v.age = 0;
  }
  renderVoice(v, outL, outR, frames) {
    const ins = v.instrument;
    if (!ins) return;
    const sr = this.sampleRate;
    const env = ins.env;
    const attackS = Math.max(1, env.attack * sr);
    const decayS = Math.max(1, env.decay * sr);
    const releaseS = Math.max(1, env.release * sr);
    const gain = ins.volume * v.velocity * (v.priority > 0 ? this.sfxGain : this.musicGain * this.musicLevel);
    const panL = Math.cos((ins.pan + 1) / 2 * (Math.PI / 2));
    const panR = Math.sin((ins.pan + 1) / 2 * (Math.PI / 2));
    const arpSteps = v.arp;
    const arpLen = arpSteps.length;
    const arpSamples = arpLen ? Math.max(1, Math.round(sr / Math.max(1, ins.arp.rate))) : 0;
    const vib = ins.vibrato;
    const vibDelay = vib.delay * sr;
    const glideStep = ins.glide > 0 ? 1 / Math.max(1, ins.glide * sr) : 0;
    const filterOn = ins.filter.type !== "off";
    const q = 1 - Math.min(0.98, Math.max(0, ins.filter.resonance));
    const maxF = 0.98 * (Math.sqrt(q * q + 4) - q);
    for (let i = 0; i < frames; i++) {
      if (v.stage === 0) {
        v.env = Math.min(1, v.env + 1 / attackS);
        if (v.env >= 1) v.stage = 1;
      } else if (v.stage === 1) {
        v.env = Math.max(env.sustain, v.env - (1 - env.sustain) / decayS);
        if (v.env <= env.sustain) v.stage = 2;
      } else if (v.stage === 3) {
        v.env = Math.max(0, v.env - v.releaseFrom / releaseS);
        if (v.env <= 5e-4) {
          v.active = false;
          v.stage = 4;
          return;
        }
      }
      if (v.releaseAt >= 0 && v.stage < 3 && v.age >= v.releaseAt) this.release(v);
      if (glideStep > 0 && v.curFreq !== v.freq) {
        const delta = v.freq - v.curFreq;
        v.curFreq = Math.abs(delta) < 0.01 ? v.freq : v.curFreq + delta * glideStep;
      } else {
        v.curFreq = v.freq;
      }
      let semis = ins.detune;
      if (arpLen) semis += arpSteps[Math.floor(v.age / arpSamples) % arpLen] ?? 0;
      if (vib.depth > 0 && v.age > vibDelay)
        semis += Math.sin(v.age / sr * vib.rate * Math.PI * 2) * vib.depth;
      const freq = semis === 0 ? v.curFreq : v.curFreq * Math.pow(2, semis / 12);
      let s;
      switch (ins.osc) {
        case "square":
          s = v.phase < ins.duty ? 1 : -1;
          break;
        case "sine":
          s = Math.sin(v.phase * Math.PI * 2);
          break;
        case "triangle":
          s = 1 - 4 * Math.abs(v.phase - 0.5);
          break;
        case "saw":
          s = v.phase * 2 - 1;
          break;
        case "noise": {
          if (v.phase < v.lastNoise) {
            v.noiseSeed ^= v.noiseSeed << 13;
            v.noiseSeed ^= v.noiseSeed >>> 17;
            v.noiseSeed ^= v.noiseSeed << 5;
          }
          v.lastNoise = v.phase;
          s = ((v.noiseSeed & 65535) / 32768 - 1) * 0.8;
          break;
        }
        case "sample": {
          if (!v.sample) {
            s = 0;
            break;
          }
          const root = midiToFrequency(ins.sampleRoot ?? 60);
          const idx = Math.floor(v.samplePos);
          s = idx < v.sample.length ? v.sample[idx] ?? 0 : 0;
          v.samplePos += freq / root;
          if (idx >= v.sample.length) {
            this.release(v);
          }
          break;
        }
      }
      v.phase += freq / sr;
      if (v.phase >= 1) v.phase -= Math.floor(v.phase);
      if (filterOn) {
        const cutoff = Math.max(
          0,
          Math.min(sr * 0.45, ins.filter.cutoff * (1 + ins.filter.envAmount * v.env))
        );
        const f = Math.min(maxF, 2 * Math.sin(Math.PI * cutoff / sr));
        v.low += f * v.band;
        const high = s - v.low - q * v.band;
        v.band += f * high;
        s = ins.filter.type === "lp" ? v.low : ins.filter.type === "hp" ? high : v.band;
      }
      const out = s * v.env * gain;
      outL[i] = (outL[i] ?? 0) + out * panL;
      outR[i] = (outR[i] ?? 0) + out * panR;
      v.age++;
    }
  }
};
var softClip = (x) => x > 1 ? 1 : x < -1 ? -1 : x - x * x * x / 3;

// src/sound/transcribe.ts
var ANALYSIS_RATE = 16e3;
var FFT_SIZE = 4096;
var SHORT_SIZE = 512;
var HOP = 256;
var LONG_WINDOW_LAG = 0.06;
var SNAP_AFTER = 0.16;
var SNAP_FRAMES = Math.ceil(SNAP_AFTER * ANALYSIS_RATE / HOP);
var CLICK_SECONDS = 0.09;
var HARMONICS = 8;
var HARMONIC_DECAY = 0.8;
var BIN_HZ = ANALYSIS_RATE / FFT_SIZE;
var FRAME_SECONDS = HOP / ANALYSIS_RATE;
function prepare(channels, rate, maxSeconds) {
  const first = channels[0];
  if (!first?.length || !(rate > 0)) throw new Error("No audio to analyse");
  const available = first.length;
  const wanted = Math.min(available, Math.floor(maxSeconds * rate));
  const ratio = rate / ANALYSIS_RATE;
  const length = Math.floor(wanted / ratio);
  const out = new Float32Array(length);
  for (let i = 0; i < length; i++) {
    const from = i * ratio, to = Math.max(from + 1, (i + 1) * ratio);
    let sum = 0, count = 0;
    for (let j = Math.floor(from); j < Math.min(Math.ceil(to), wanted); j++) {
      let mixed = 0;
      for (const channel of channels) mixed += channel[j] ?? 0;
      sum += mixed / channels.length;
      count++;
    }
    out[i] = count ? sum / count : 0;
  }
  let peak = 0;
  for (const v of out) peak = Math.max(peak, Math.abs(v));
  if (peak > 0) for (let i = 0; i < length; i++) out[i] = (out[i] ?? 0) / peak;
  return { signal: out, truncated: wanted < available };
}
function fft(re, im) {
  const n = re.length;
  for (let i = 1, j = 0; i < n; i++) {
    let bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) {
      [re[i], re[j]] = [re[j] ?? 0, re[i] ?? 0];
      [im[i], im[j]] = [im[j] ?? 0, im[i] ?? 0];
    }
  }
  for (let size = 2; size <= n; size <<= 1) {
    const angle = -2 * Math.PI / size;
    const wr = Math.cos(angle), wi = Math.sin(angle);
    for (let start = 0; start < n; start += size) {
      let cr = 1, ci = 0;
      for (let k = 0; k < size / 2; k++) {
        const a = start + k, b = a + size / 2;
        const tr = (re[b] ?? 0) * cr - (im[b] ?? 0) * ci, ti = (re[b] ?? 0) * ci + (im[b] ?? 0) * cr;
        re[b] = (re[a] ?? 0) - tr;
        im[b] = (im[a] ?? 0) - ti;
        re[a] = (re[a] ?? 0) + tr;
        im[a] = (im[a] ?? 0) + ti;
        const next = cr * wr - ci * wi;
        ci = cr * wi + ci * wr;
        cr = next;
      }
    }
  }
}
var frequencyOf = (pitch) => 440 * Math.pow(2, (pitch - 69) / 12);
var pitchClassOf = (pitch) => (Math.round(pitch) % 12 + 12) % 12;
function analyse(signal, lowest, highest, voices) {
  const frames = Math.max(1, Math.floor(signal.length / HOP));
  const half = FFT_SIZE / 2;
  const window = Float64Array.from(
    { length: FFT_SIZE },
    (_, i) => 0.5 - 0.5 * Math.cos(2 * Math.PI * i / FFT_SIZE)
  );
  const norm = FFT_SIZE / 4;
  const pcOfBin = Int8Array.from({ length: half }, (_, k) => {
    const f = k * BIN_HZ;
    return f < 50 || f > 4e3 ? -1 : pitchClassOf(69 + 12 * Math.log2(f / 440));
  });
  const bands = Array.from({ length: highest - lowest + 1 }, (_, i) => {
    const f0 = frequencyOf(lowest + i);
    const out = [];
    for (let h = 1; h <= HARMONICS; h++) {
      const f = f0 * h;
      if (f > ANALYSIS_RATE * 0.45) break;
      out.push([
        Math.max(1, Math.floor(f * Math.pow(2, -1 / 24) / BIN_HZ)),
        Math.min(half - 1, Math.ceil(f * Math.pow(2, 1 / 24) / BIN_HZ)),
        Math.pow(HARMONIC_DECAY, h - 1)
      ]);
    }
    return out;
  });
  const chroma = new Float32Array(frames * 12);
  const energy = new Float32Array(frames);
  const power = new Float32Array(frames);
  const lowPower = new Float32Array(frames);
  const flux = new Float32Array(frames);
  const flatness = new Float32Array(frames);
  const lowRatio = new Float32Array(frames);
  const centroid = new Float32Array(frames);
  const candidates = [];
  const re = new Float64Array(FFT_SIZE), im = new Float64Array(FFT_SIZE);
  const compressed = new Float64Array(half), work = new Float64Array(half);
  const shortHalf = SHORT_SIZE / 2, shortBin = ANALYSIS_RATE / SHORT_SIZE;
  const shortWindow = Float64Array.from(
    { length: SHORT_SIZE },
    (_, i) => 0.5 - 0.5 * Math.cos(2 * Math.PI * i / SHORT_SIZE)
  );
  const sre = new Float64Array(SHORT_SIZE), sim = new Float64Array(SHORT_SIZE), shortPrevious = new Float64Array(shortHalf);
  const lowBin = Math.floor(4e3 / BIN_HZ);
  for (let f = 0; f < frames; f++) {
    const centre = f * HOP;
    for (let i = 0; i < FFT_SIZE; i++) {
      re[i] = (signal[centre - half + i] ?? 0) * (window[i] ?? 0);
      im[i] = 0;
    }
    fft(re, im);
    let total = 0, pw = 0, pwLow = 0;
    for (let k = 1; k < half; k++) {
      const magnitude = Math.hypot(re[k] ?? 0, im[k] ?? 0) / norm;
      const c = Math.log1p(100 * magnitude);
      compressed[k] = c;
      total += c;
      const p = magnitude * magnitude;
      pw += p;
      if (k < lowBin) pwLow += p;
      const pc = pcOfBin[k] ?? 0;
      if (pc >= 0) chroma[f * 12 + pc] = (chroma[f * 12 + pc] ?? 0) + c;
    }
    energy[f] = total;
    power[f] = pw;
    lowPower[f] = pwLow;
    for (let i = 0; i < SHORT_SIZE; i++) {
      sre[i] = (signal[centre - shortHalf + i] ?? 0) * (shortWindow[i] ?? 0);
      sim[i] = 0;
    }
    fft(sre, sim);
    let rise = 0, logSum = 0, linSum = 0, weighted = 0, low = 0, all = 0, counted = 0;
    for (let k = 1; k < shortHalf; k++) {
      const magnitude = Math.hypot(sre[k] ?? 0, sim[k] ?? 0) / (SHORT_SIZE / 4);
      const c = Math.log1p(100 * magnitude);
      rise += Math.max(0, c - (shortPrevious[k] ?? 0));
      shortPrevious[k] = c;
      const freq = k * shortBin;
      if (freq >= 100) {
        logSum += Math.log(magnitude + 1e-9);
        linSum += magnitude;
        counted++;
      }
      weighted += freq * magnitude;
      all += magnitude;
      if (freq < 200) low += magnitude;
    }
    flux[f] = rise;
    flatness[f] = linSum > 0 ? Math.exp(logSum / counted) / (linSum / counted) : 0;
    lowRatio[f] = all > 0 ? low / all : 0;
    centroid[f] = all > 0 ? weighted / all : 0;
    work.set(compressed);
    const found = [];
    for (let v = 0; v < voices + 1; v++) {
      let best = -1, bestSalience = 0;
      for (let n = 0; n < bands.length; n++) {
        let salience = 0;
        for (const [a, b, w] of bands[n] ?? []) {
          let peak = 0;
          for (let k = a; k <= b; k++) peak = Math.max(peak, work[k] ?? 0);
          salience += w * peak;
        }
        if (salience > bestSalience) {
          bestSalience = salience;
          best = n;
        }
      }
      if (best < 0 || bestSalience <= 0) break;
      found.push({ pitch: lowest + best, salience: bestSalience });
      const [fa, fb] = bands[best]?.[0] ?? [0, -1];
      let reference = 0;
      for (let k = fa; k <= fb; k++) reference = Math.max(reference, work[k] ?? 0);
      for (const [a, b, w] of bands[best] ?? []) {
        let present = 0;
        for (let k = a; k <= b; k++) present = Math.max(present, work[k] ?? 0);
        const expected = Math.max(reference * w, 0.6 * present);
        for (let k = Math.max(1, a - 1); k <= Math.min(half - 1, b + 1); k++)
          work[k] = Math.max(0, (work[k] ?? 0) - expected);
      }
    }
    candidates.push(found);
  }
  let maxEnergy = 0;
  for (const e of energy) maxEnergy = Math.max(maxEnergy, e);
  if (maxEnergy > 0) for (let f = 0; f < frames; f++) energy[f] = (energy[f] ?? 0) / maxEnergy;
  return {
    analysis: {
      frames,
      duration: frames * FRAME_SECONDS,
      chroma,
      energy,
      power,
      lowPower,
      onsets: onsetsOf(flux).map((f) => f * FRAME_SECONDS)
    },
    candidates,
    flux,
    flatness,
    lowRatio,
    centroid
  };
}
function onsetsOf(flux) {
  let max = 0;
  for (const v of flux) max = Math.max(max, v);
  if (max <= 0) return [];
  const norm = Float32Array.from(flux, (v) => v / max);
  const out = [];
  for (let f = 1; f < norm.length - 1; f++) {
    const around = Array.from(norm.subarray(Math.max(0, f - 8), f + 9)).sort((a, b) => a - b);
    const median = around[Math.floor(around.length / 2)] ?? 0;
    let peak = true;
    for (let g = Math.max(0, f - 3); g <= Math.min(norm.length - 1, f + 3); g++)
      if ((norm[g] ?? 0) > (norm[f] ?? 0)) peak = false;
    if (peak && (norm[f] ?? 0) > median * 1.5 + 0.06 && (!out.length || f - (out[out.length - 1] ?? 0) >= 3))
      out.push(f);
  }
  return out;
}
function tempoOf(flux) {
  const framesPerSecond = 1 / FRAME_SECONDS;
  let bestBpm = 120, bestScore = 0;
  for (let bpm = 60; bpm <= 200; bpm++) {
    const lag = 60 * framesPerSecond / bpm;
    let score = 0;
    for (let f = 0; f + 2 * lag + 1 < flux.length; f++) {
      const at = (x) => {
        const i = Math.floor(x);
        return (flux[i] ?? 0) + ((flux[i + 1] ?? 0) - (flux[i] ?? 0)) * (x - i);
      };
      score += (flux[f] ?? 0) * (at(f + lag) + 0.5 * at(f + 2 * lag));
    }
    score *= Math.exp(-0.5 * Math.pow(Math.log2(bpm / 120) / 0.9, 2));
    if (score > bestScore) {
      bestScore = score;
      bestBpm = bpm;
    }
  }
  return bestBpm;
}
function trackNotes(frames, sensitivity) {
  const { candidates } = frames;
  let peak = 0;
  for (const found of candidates) peak = Math.max(peak, found[0]?.salience ?? 0);
  const absolute = peak * (0.28 - 0.2 * sensitivity);
  const byPitch = /* @__PURE__ */ new Map();
  candidates.forEach((found, f) => {
    const first = found[0]?.salience ?? 0;
    if ((frames.analysis.energy[f] ?? 0) < 0.02) return;
    for (const { pitch, salience } of found) {
      if (salience < absolute || salience < first * (0.45 - 0.2 * sensitivity)) continue;
      let row = byPitch.get(pitch);
      if (!row) {
        row = new Float32Array(candidates.length);
        byPitch.set(pitch, row);
      }
      row[f] = salience;
    }
  });
  const onsetFrames = new Set(frames.analysis.onsets.map((t) => Math.round(t / FRAME_SECONDS)));
  const notes = [];
  const minFrames = 4, gap = 2;
  const onsets = frames.analysis.onsets;
  const emit = (pitch, row, from, to) => {
    if (to - from < minFrames) return;
    let sum = 0;
    for (let f = from; f < to; f++) sum += row[f] ?? 0;
    const strength = sum / (to - from) / (0.7 * peak);
    const seen = from * FRAME_SECONDS;
    const expected = seen + LONG_WINDOW_LAG;
    const near = onsets.filter((t) => t >= seen - 0.03 && t <= seen + SNAP_AFTER);
    const start = near.length ? near.reduce((a, b) => Math.abs(b - expected) < Math.abs(a - expected) ? b : a) : expected;
    const end = Math.max(start + 0.05, to * FRAME_SECONDS - LONG_WINDOW_LAG);
    notes.push({
      start,
      end,
      pitch,
      velocity: Math.max(1, Math.min(127, Math.round(40 + 87 * Math.min(1, strength)))),
      channel: 0
    });
  };
  for (const [pitch, row] of byPitch) {
    let start = -1, last = -1;
    for (let f = 0; f <= row.length; f++) {
      const on = f < row.length && (row[f] ?? 0) > 0;
      if (on && start >= 0 && onsetFrames.has(f) && f - start > SNAP_FRAMES) {
        const before = Math.min(...[1, 2, 3].map((d) => row[f - d] ?? 0).filter((v) => v > 0));
        if ((row[f] ?? 0) > 1.25 * before) {
          emit(pitch, row, start, last + 1);
          start = f;
        }
      }
      if (on) {
        if (start < 0) start = f;
        last = f;
      } else if (start >= 0 && (f - last > gap || f === row.length)) {
        emit(pitch, row, start, last + 1);
        start = -1;
      }
    }
  }
  const length = (n) => n.end - n.start;
  const kept = notes.filter(
    (n) => !notes.some(
      (m) => m !== n && Math.abs(m.pitch - n.pitch) === 1 && m.velocity >= n.velocity && length(m) >= 2 * length(n) && Math.min(m.end, n.end) - Math.max(m.start, n.start) >= 0.8 * length(n)
    )
  );
  const short = kept.filter((n) => length(n) <= CLICK_SECONDS);
  const clicks = /* @__PURE__ */ new Set();
  for (const m of kept) {
    if (length(m) <= 2 * CLICK_SECONDS) continue;
    const before = short.filter(
      (n) => m.start - n.start >= -0.04 && m.start - n.start <= SNAP_AFTER
    );
    const after = short.filter((n) => n.start - m.end >= -0.04 && n.start - m.end <= 0.12);
    const latest = Math.max(...before.map((n) => n.start));
    const earliest = Math.min(...after.map((n) => n.start));
    for (const n of before) if (n.start >= latest - 0.02) clicks.add(n);
    for (const n of after) if (n.start <= earliest + 0.02) clicks.add(n);
    if (before.length) m.start = Math.min(m.start, latest);
    if (after.length) m.end = Math.max(m.end, earliest);
  }
  const clean = kept.filter((n) => !clicks.has(n));
  return { notes: clean.sort((a, b) => a.start - b.start || a.pitch - b.pitch), peak };
}
function drumHits(frames, pitched) {
  const out = [];
  let maxFlux = 0;
  for (const v of frames.flux) maxFlux = Math.max(maxFlux, v);
  for (const t of frames.analysis.onsets) {
    const f = Math.round(t / FRAME_SECONDS);
    const flat = frames.flatness[f] ?? 0, low = frames.lowRatio[f] ?? 0;
    const pitchedStart = pitched.some((n) => Math.abs(n.start - t) < 0.05);
    if (flat < 0.3 && !(low > 0.55 && !pitchedStart)) continue;
    const key = low > 0.45 ? 36 : (frames.centroid[f] ?? 0) > 3500 ? 42 : 38;
    const velocity = Math.max(
      30,
      Math.min(127, Math.round(127 * (frames.flux[f] ?? 0) / (maxFlux || 1)))
    );
    out.push({ start: t, end: t + 0.1, pitch: key, velocity, channel: 9 });
  }
  return out;
}
function scoreNotes(analysis, notes) {
  const synth = new Float32Array(analysis.frames * 12);
  for (const note of notes) {
    if (note.drum) continue;
    const from = Math.max(0, Math.floor(note.start / FRAME_SECONDS)), to = Math.min(analysis.frames, Math.ceil(note.end / FRAME_SECONDS));
    for (let h = 1; h <= HARMONICS; h++) {
      const pc = pitchClassOf(note.pitch + 12 * Math.log2(h));
      const weight = note.velocity / 127 * Math.pow(HARMONIC_DECAY, h - 1);
      for (let f = from; f < to; f++) synth[f * 12 + pc] = (synth[f * 12 + pc] ?? 0) + weight;
    }
  }
  let similar = 0, weights = 0;
  for (let f = 0; f < analysis.frames; f++) {
    let dot = 0, a = 0, b = 0;
    for (let k = 0; k < 12; k++) {
      const x = analysis.chroma[f * 12 + k] ?? 0, y = synth[f * 12 + k] ?? 0;
      dot += x * y;
      a += x * x;
      b += y * y;
    }
    const loud = analysis.energy[f] ?? 0;
    const weight = loud > 0.05 ? loud : b > 0 ? 0.2 : 0;
    if (!weight) continue;
    weights += weight;
    if (a > 0 && b > 0) similar += weight * (dot / Math.sqrt(a * b));
  }
  const harmony = weights ? similar / weights : 1;
  const starts = [...new Set(notes.map((n) => Math.round(n.start * 1e3 / 30)))].map((v) => v * 0.03).sort((x, y) => x - y);
  const reference = analysis.onsets;
  let matched = 0;
  const used = /* @__PURE__ */ new Set();
  for (const t of reference) {
    const hit = starts.findIndex((s, i) => !used.has(i) && Math.abs(s - t) <= 0.07);
    if (hit >= 0) {
      used.add(hit);
      matched++;
    }
  }
  const rhythm = !reference.length && !starts.length ? 1 : 2 * matched / (reference.length + starts.length || 1);
  const fidelity = Math.round(100 * (0.65 * harmony + 0.35 * rhythm));
  return {
    fidelity,
    loss: 100 - fidelity,
    harmony: Math.round(100 * harmony),
    rhythm: Math.round(100 * rhythm)
  };
}
function notesOfImport(conversion) {
  const drums = new Set(conversion.instruments.filter((i) => i.osc === "noise").map((i) => i.id));
  const byId = new Map(conversion.patterns.map((p) => [p.id, p]));
  const out = [];
  let offset = 0;
  for (const id of conversion.song.sequence) {
    const pattern = byId.get(id);
    if (!pattern) continue;
    const seconds = 60 / (pattern.bpm * pattern.stepsPerBeat);
    for (const note of pattern.notes) {
      const start = offset + note.step * seconds;
      out.push({
        start,
        end: start + note.length * seconds,
        pitch: note.pitch,
        velocity: Math.round(note.volume * 127),
        drum: drums.has(note.instrument)
      });
    }
    offset += pattern.steps * seconds;
  }
  return out;
}
function scoreImport(analysis, conversion) {
  return scoreNotes(analysis, notesOfImport(conversion));
}
function scoreSample(analysis, seconds) {
  let total = 0, kept = 0;
  for (let f = 0; f < analysis.frames; f++) {
    total += analysis.power[f] ?? 0;
    if (f * FRAME_SECONDS < seconds) kept += analysis.lowPower[f] ?? 0;
  }
  const fidelity = total > 0 ? Math.round(100 * kept / total) : 100;
  return { fidelity, loss: 100 - fidelity, harmony: fidelity, rhythm: fidelity };
}
function analyseAudio(channels, sampleRate, maxSeconds = 180) {
  const { signal } = prepare(channels, sampleRate, maxSeconds);
  return analyse(signal, 36, 96, 1).analysis;
}
function transcribe(channels, sampleRate, options = {}) {
  const voices = Math.max(1, Math.min(6, Math.round(options.voices ?? 4)));
  const lowest = Math.max(24, Math.min(100, options.lowest ?? 36));
  const highest = Math.max(lowest + 12, Math.min(108, options.highest ?? 96));
  const sensitivity = Math.max(0, Math.min(1, options.sensitivity ?? 0.5));
  const { signal, truncated } = prepare(channels, sampleRate, options.maxSeconds ?? 180);
  const frames = analyse(signal, lowest, highest, voices);
  const { notes } = trackNotes(frames, sensitivity);
  const bpm = tempoOf(frames.flux);
  const eighth = Math.max(0.06, 30 / bpm);
  const pitched = notes.filter(
    (n) => n.end - n.start >= eighth || notes.some((m) => m !== n && Math.abs(m.start - n.start) < eighth)
  );
  const drums = options.drums === false ? [] : drumHits(frames, pitched);
  const track = (index, name, list, channel) => ({
    index,
    name,
    notes: list,
    channels: list.length ? [channel] : [],
    program: null,
    percussion: channel === 9 && list.length > 0
  });
  const tracks = [track(0, "melody & harmony", pitched, 0), track(1, "drums", drums, 9)].filter(
    (t) => t.notes.length
  );
  const warnings = [
    "Transcribed from audio: pitches, timing and drums are estimates; timbre, effects and vocals are not kept."
  ];
  if (truncated)
    warnings.push(`Only the first ${String(options.maxSeconds ?? 180)} seconds were analysed.`);
  if (!tracks.length) throw new Error("No notes were found in this recording");
  const midi = {
    tracks,
    bpm,
    tempoChanges: 0,
    sustained: 0,
    warnings,
    duration: Math.max(...tracks.flatMap((t) => t.notes.map((n) => n.end)))
  };
  const quality = scoreNotes(
    frames.analysis,
    [...pitched, ...drums].map((n) => ({ ...n, drum: n.channel === 9 }))
  );
  return { midi, analysis: frames.analysis, quality, truncated };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ANALYSIS_RATE,
  MAX_SAMPLE_BYTES,
  MAX_SAMPLE_SECONDS,
  NOTE_NAMES,
  SAMPLE_RATE,
  SONG_SLOTS,
  SUBSTEPS,
  Sequencer,
  SynthCore,
  VOICES,
  analyseAudio,
  chipInstrument,
  convertMidi,
  decodeSample,
  defaultInstrument,
  defaultPattern,
  defaultSong,
  drumPitch,
  encodeSample,
  midiToFrequency,
  midiToNoteName,
  noteNameToMidi,
  notesOfImport,
  readMidi,
  scoreImport,
  scoreNotes,
  scoreSample,
  toSampleBytes,
  transcribe,
  writeMidi
});
