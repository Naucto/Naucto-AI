"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/headless.ts
var headless_exports = {};
__export(headless_exports, {
  DEFAULT_GEOMETRY: () => DEFAULT_GEOMETRY,
  FIRST_MAP_ID: () => FIRST_MAP_ID,
  FIRST_SHEET_ID: () => FIRST_SHEET_ID,
  GAME_SCHEMA_VERSION: () => GAME_SCHEMA_VERSION,
  GEOMETRY_KEYS: () => GEOMETRY_KEYS,
  Game: () => Game,
  KEYS: () => KEYS,
  LEGACY_KEYS: () => LEGACY_KEYS,
  MAIN_FILE: () => MAIN_FILE,
  MAIN_FILE_ID: () => MAIN_FILE_ID,
  MAP_HEIGHT: () => MAP_HEIGHT,
  MAP_WIDTH: () => MAP_WIDTH,
  MAX_MAP_SIZE: () => MAX_MAP_SIZE,
  MAX_SHEET_SIZE: () => MAX_SHEET_SIZE,
  MIN_MAP_SIZE: () => MIN_MAP_SIZE,
  MIN_SHEET_SIZE: () => MIN_SHEET_SIZE,
  PALETTE_SIZE: () => PALETTE_SIZE,
  SCREEN_HEIGHT: () => SCREEN_HEIGHT,
  SCREEN_WIDTH: () => SCREEN_WIDTH,
  SHEET_HEIGHT: () => SHEET_HEIGHT,
  SHEET_WIDTH: () => SHEET_WIDTH,
  SIZE_STEP: () => SIZE_STEP,
  SPRITES_PER_ROW: () => SPRITES_PER_ROW,
  SPRITE_COUNT: () => SPRITE_COUNT,
  SPRITE_SIZE: () => SPRITE_SIZE,
  aiContext: () => aiContext,
  clampMapSize: () => clampMapSize,
  clampSheetSize: () => clampSheetSize,
  encodeState: () => encodeState,
  gameFromState: () => gameFromState,
  geometryOf: () => geometryOf,
  readGeometry: () => readGeometry
});
module.exports = __toCommonJS(headless_exports);

// src/game/ai.ts
var Y2 = __toESM(require("yjs"), 1);

// src/game/Game.ts
var Y = __toESM(require("yjs"), 1);

// src/input/ActionMap.ts
var ACTIONS = ["left", "right", "up", "down", "a", "b", "x", "y", "pause"];
var ACTION_BIT = {
  left: 1 << 0,
  right: 1 << 1,
  up: 1 << 2,
  down: 1 << 3,
  a: 1 << 4,
  b: 1 << 5,
  x: 1 << 6,
  y: 1 << 7,
  pause: 1 << 8
};
var isAction = (v) => typeof v === "string" && ACTIONS.includes(v);

// src/game/defaults.ts
var BUBBLEGUM_16 = [
  "#16171a",
  "#7f0622",
  "#d62411",
  "#ff8426",
  "#ffd100",
  "#fafdff",
  "#ff80a4",
  "#ff2674",
  "#94216a",
  "#430067",
  "#234975",
  "#68aed4",
  "#bfff3c",
  "#10d275",
  "#007899",
  "#002859"
];
var DEFAULT_GAME_CODE = `-- Naucto starter game
-- Move the moon with the arrow keys, WASD or a gamepad.

local player = {
  x = 152,
  y = 82,
  speed = 2,
}

function _init()
  print("Welcome to Naucto!")
end

function _update()
  if input.held("left") then player.x = player.x - player.speed end
  if input.held("right") then player.x = player.x + player.speed end
  if input.held("up") then player.y = player.y - player.speed end
  if input.held("down") then player.y = player.y + player.speed end
end

function _draw()
  gfx.clear(0)
  -- The moon is a 16x16 block of the sheet, drawn in one go.
  gfx.draw_region(8, 0, 16, 16, player.x, player.y)
end
`;
var DEFAULT_PLAYER_SPRITE = [
  ".....aaaaaa.....",
  "....aaaaaaaaa...",
  "...aa.aaaaaaa...",
  "..aa...aaa......",
  "..a.....a.......",
  ".aaa...a........",
  ".aaaa.aa........",
  ".aaaaaa.........",
  ".aaaaaa........a",
  ".aaaaaaa......aa",
  "..aaaaaa.....aaa",
  "..aaaaaaa...aaaa",
  "...aaaaaaaaaaaa.",
  "....aaaaaaaaaa..",
  ".....aaaaaaaa...",
  "................"
];
var DEFAULT_PLAYER_SPRITE_INDICES = [1, 2, 17, 18];
var DEFAULT_SPRITE_COLOUR = 4;

// src/game/GameMap.ts
var GameMap = class {
  constructor(id, name, order, width, height, colour, tiles, writer) {
    this.id = id;
    this.name = name;
    this.order = order;
    this.width = width;
    this.height = height;
    this.colour = colour;
    this.tiles = tiles;
    this.writer = writer;
  }
  id;
  name;
  order;
  width;
  height;
  colour;
  tiles;
  writer;
  getTile(x, y) {
    if (x < 0 || x >= this.width || y < 0 || y >= this.height) return 0;
    return this.tiles[y * this.width + x] ?? 0;
  }
  setTile(x, y, sprite) {
    if (x < 0 || x >= this.width || y < 0 || y >= this.height) return;
    this.writer.setTile(this.id, x, y, sprite);
  }
};

// src/game/keys.ts
var GAME_SCHEMA_VERSION = 2;
var KEYS = {
  meta: "game.meta",
  codeFiles: "code.files",
  codeMeta: "code.meta",
  palette: "gfx.palette",
  sheets: "gfx.sheets",
  sprites: "gfx.sprites",
  flags: "gfx.flags",
  maps: "map.maps",
  tiles: "map.tiles",
  instruments: "sound.instruments",
  patterns: "sound.patterns",
  sfx: "sound.sfx",
  songs: "sound.songs",
  samples: "sound.samples",
  netPermissions: "net.permissions",
  // Project metadata texts mirrored to the backend; unchanged from v0.
  projectName: "projectName",
  shortDescription: "shortDescription",
  longDescription: "longDescription",
  iconUrl: "iconUrl",
  projectTags: "projectTags"
};
var LEGACY_KEYS = {
  code: "monaco",
  sprites: "sprite",
  flags: "sprite_flags",
  tiles: "map",
  musics: "sound_musics",
  selectedMusic: "sound_selectedIndex",
  customInstruments: "sound_customInstruments",
  netPermissions: "multiplayerDirectory"
};
var SCREEN_WIDTH = 320;
var SCREEN_HEIGHT = 180;
var SPRITE_SIZE = 8;
var SHEET_WIDTH = 128;
var SHEET_HEIGHT = 128;
var SPRITES_PER_ROW = SHEET_WIDTH / SPRITE_SIZE;
var SPRITE_COUNT = SPRITES_PER_ROW * (SHEET_HEIGHT / SPRITE_SIZE);
var MAP_WIDTH = 128;
var MAP_HEIGHT = 32;
var PALETTE_SIZE = 16;
var MAIN_FILE = "main";
var MAIN_FILE_ID = "main";
var FIRST_SHEET_ID = "0";
var FIRST_MAP_ID = "0";

// src/game/geometry.ts
var SIZE_STEP = SPRITE_SIZE;
var MIN_SHEET_SIZE = SIZE_STEP;
var MAX_SHEET_SIZE = 256;
var MIN_MAP_SIZE = 1;
var MAX_MAP_SIZE = 256;
var GEOMETRY_KEYS = {
  sheetWidth: "sheetWidth",
  sheetHeight: "sheetHeight",
  mapWidth: "mapWidth",
  mapHeight: "mapHeight"
};
function clampSheetSize(n) {
  const stepped = Math.round(n / SIZE_STEP) * SIZE_STEP;
  return Math.max(MIN_SHEET_SIZE, Math.min(MAX_SHEET_SIZE, stepped));
}
function clampMapSize(n) {
  return Math.max(MIN_MAP_SIZE, Math.min(MAX_MAP_SIZE, Math.round(n)));
}
function geometryOf(sheetWidth, sheetHeight, mapWidth, mapHeight) {
  const spritesPerRow = sheetWidth / SPRITE_SIZE;
  const spriteRows = sheetHeight / SPRITE_SIZE;
  return {
    sheetWidth,
    sheetHeight,
    spritesPerRow,
    spriteRows,
    spriteCount: spritesPerRow * spriteRows,
    mapWidth,
    mapHeight
  };
}
var DEFAULT_GEOMETRY = geometryOf(
  SHEET_WIDTH,
  SHEET_HEIGHT,
  MAP_WIDTH,
  MAP_HEIGHT
);
function sizeFrom(meta, key, fallback) {
  const v = meta.get(key);
  return typeof v === "number" && Number.isFinite(v) && v > 0 ? v : fallback;
}
function readGeometry(meta) {
  return geometryOf(
    clampSheetSize(sizeFrom(meta, GEOMETRY_KEYS.sheetWidth, SHEET_WIDTH)),
    clampSheetSize(sizeFrom(meta, GEOMETRY_KEYS.sheetHeight, SHEET_HEIGHT)),
    clampMapSize(sizeFrom(meta, GEOMETRY_KEYS.mapWidth, MAP_WIDTH)),
    clampMapSize(sizeFrom(meta, GEOMETRY_KEYS.mapHeight, MAP_HEIGHT))
  );
}

// src/game/luaScan.ts
function longBracketEnd(s, at) {
  const open = /^\[(=*)\[/.exec(s.slice(at, at + 16));
  if (!open) return null;
  const close = `]${open[1] ?? ""}]`;
  const end = s.indexOf(close, at + open[0].length);
  return end === -1 ? s.length : end + close.length;
}
function skipDead(s, at) {
  if (s.startsWith("--", at)) {
    const long2 = longBracketEnd(s, at + 2);
    if (long2 !== null) return long2;
    const end = s.indexOf("\n", at);
    return end === -1 ? s.length : end;
  }
  const long = longBracketEnd(s, at);
  if (long !== null) return long;
  const quote = s[at];
  if (quote !== '"' && quote !== "'") return at;
  let i = at + 1;
  while (i < s.length && s[i] !== quote && s[i] !== "\n") i += s[i] === "\\" ? 2 : 1;
  return Math.min(i + 1, s.length);
}
function matchesName(s, at, name) {
  if (!s.startsWith(name, at)) return false;
  const before = s[at - 1];
  if (before !== void 0 && /[\w.]/.test(before)) return false;
  const after = s[at + name.length];
  return after === void 0 || !/\w/.test(after);
}
function matchesCall(s, at, name) {
  return matchesName(s, at, name) && /^\s*\(/.test(s.slice(at + name.length));
}
function splitArgs(s, from) {
  const parts = [];
  let depth = 0;
  let start = from;
  let i = from;
  while (i < s.length) {
    const skipped = skipDead(s, i);
    if (skipped > i) {
      i = skipped;
      continue;
    }
    const c = s[i];
    if (c === "(" || c === "[" || c === "{") depth += 1;
    else if (c === ")" && depth === 0) {
      parts.push(s.slice(start, i));
      return { parts, end: i };
    } else if (c === ")" || c === "]" || c === "}") depth -= 1;
    else if (c === "," && depth === 0) {
      parts.push(s.slice(start, i));
      start = i + 1;
    }
    i += 1;
  }
  return null;
}

// src/game/renumber.ts
var cellsOf = (s) => ({
  cols: s.width / SPRITE_SIZE,
  rows: s.height / SPRITE_SIZE
});
function remapSprites(before, after) {
  const now = new Map(after.map((s) => [s.id, s]));
  const moves = /* @__PURE__ */ new Map();
  for (const was of before) {
    const is = now.get(was.id);
    const old = cellsOf(was);
    if (!is) continue;
    const next = cellsOf(is);
    for (let row = 0; row < old.rows; row++)
      for (let col = 0; col < old.cols; col++) {
        if (col >= next.cols || row >= next.rows) continue;
        const from = was.base + row * old.cols + col;
        const to = is.base + row * next.cols + col;
        if (from !== to) moves.set(from, to);
      }
  }
  return moves;
}
function survives(n, before, after) {
  const was = before.find((s) => n >= s.base && n < s.base + cellsOf(s).cols * cellsOf(s).rows);
  if (!was) return false;
  const is = after.find((s) => s.id === was.id);
  if (!is) return false;
  const old = cellsOf(was);
  const next = cellsOf(is);
  const local = n - was.base;
  return local % old.cols < next.cols && Math.floor(local / old.cols) < next.rows;
}
var CALLS = [
  { name: "gfx.draw_sprite", arg: 0 },
  { name: "sprite", arg: 0 },
  { name: "map.set", arg: 2 },
  { name: "map.flag", arg: 0 },
  { name: "fget", arg: 0 }
];
function rewriteSpriteNumbers(source, remap) {
  let out = "";
  let changed = 0;
  let unsure = 0;
  let i = 0;
  while (i < source.length) {
    const skipped = skipDead(source, i);
    if (skipped > i) {
      out += source.slice(i, skipped);
      i = skipped;
      continue;
    }
    const call = CALLS.find((c) => matchesCall(source, i, c.name));
    if (!call) {
      out += source.slice(i, i + 1);
      i += 1;
      continue;
    }
    const open = source.indexOf("(", i + call.name.length);
    out += source.slice(i, open + 1);
    i = open + 1;
    const args = splitArgs(source, i);
    if (!args) continue;
    const wanted = args.parts[call.arg];
    if (wanted === void 0) {
      out += source.slice(i, args.end);
      i = args.end;
      continue;
    }
    const literal = /^\s*(\d+)\s*$/.exec(wanted);
    if (!literal) {
      unsure += 1;
      out += source.slice(i, args.end);
      i = args.end;
      continue;
    }
    const from = Number(literal[1]);
    const to = remap.get(from);
    if (to !== void 0) {
      changed += 1;
      args.parts[call.arg] = wanted.replace(String(from), String(to));
    }
    out += args.parts.join(",");
    i = args.end;
  }
  return { text: out, changed, unsure };
}

// src/game/Sheet.ts
var Sheet = class {
  constructor(id, name, order, width, height, base, colour, pixels, flags, writer) {
    this.id = id;
    this.name = name;
    this.order = order;
    this.width = width;
    this.height = height;
    this.base = base;
    this.colour = colour;
    this.pixels = pixels;
    this.flags = flags;
    this.writer = writer;
    this.cols = width / SPRITE_SIZE;
    this.rows = height / SPRITE_SIZE;
    this.count = this.cols * this.rows;
  }
  id;
  name;
  order;
  width;
  height;
  base;
  colour;
  pixels;
  flags;
  writer;
  cols;
  rows;
  count;
  /** Whether a sprite number is one of this sheet's. */
  holds(sprite) {
    return sprite >= this.base && sprite < this.base + this.count;
  }
  /** Where a sprite number starts on this sheet, in its own pixels. */
  originOf(sprite) {
    const local = sprite - this.base;
    return {
      x: local % this.cols * SPRITE_SIZE,
      y: Math.floor(local / this.cols) * SPRITE_SIZE
    };
  }
  getPixel(x, y) {
    if (x < 0 || x >= this.width || y < 0 || y >= this.height) return 0;
    return this.pixels[y * this.width + x] ?? 0;
  }
  setPixel(x, y, colour) {
    if (x < 0 || x >= this.width || y < 0 || y >= this.height) return;
    this.writer.setPixel(this.id, x, y, colour);
  }
  getFlag(sprite) {
    return this.flags[sprite - this.base] ?? 0;
  }
  setFlag(sprite, value) {
    const local = sprite - this.base;
    if (local < 0 || local >= this.count) return;
    this.writer.setFlag(this.id, local, value);
  }
  isEmpty(sprite) {
    const { x: ox, y: oy } = this.originOf(sprite);
    for (let y = 0; y < SPRITE_SIZE; y++)
      for (let x = 0; x < SPRITE_SIZE; x++) if (this.getPixel(ox + x, oy + y) !== 0) return false;
    return true;
  }
};

// src/game/Game.ts
var NOT_A_SPRITE = -1;
var NO_PIXELS = new Uint8Array(0);
var NO_TILES = new Uint16Array(0);
var coordKey = (x, y) => `${String(x)},${String(y)}`;
var parseCoord = (key) => {
  const i = key.indexOf(",");
  return [Number(key.slice(0, i)), Number(key.slice(i + 1))];
};
var LOCAL_ORIGIN = "local";
var RESTORED_TEXTS = [
  KEYS.projectName,
  KEYS.shortDescription,
  KEYS.longDescription,
  KEYS.iconUrl,
  KEYS.projectTags
];
function replaceMap(target, source) {
  for (const key of [...target.keys()]) {
    if (!source.has(key)) target.delete(key);
  }
  source.forEach((value, key) => {
    if (target.get(key) !== value) target.set(key, value);
  });
}
function replaceArray(target, source) {
  const wanted = source.toArray();
  if (target.length === wanted.length && target.toArray().every((v, i) => v === wanted[i])) return;
  target.delete(0, target.length);
  target.insert(0, wanted);
}
function replaceText(target, wanted) {
  const current = target.toString();
  if (current === wanted) return;
  let head = 0;
  const max = Math.min(current.length, wanted.length);
  while (head < max && current[head] === wanted[head]) head++;
  let tail = 0;
  while (tail < max - head && current[current.length - 1 - tail] === wanted[wanted.length - 1 - tail])
    tail++;
  const removed = current.length - head - tail;
  if (removed > 0) target.delete(head, removed);
  const added = wanted.slice(head, wanted.length - tail);
  if (added) target.insert(head, added);
}
function numberOf(entry, key, fallback) {
  const v = entry.get(key);
  return typeof v === "number" && Number.isFinite(v) ? v : fallback;
}
function colourOf(entry) {
  const v = entry.get("colour");
  return typeof v === "number" ? v : null;
}
function stringOf(entry, key, fallback) {
  const v = entry.get(key);
  return typeof v === "string" ? v : fallback;
}
var Game = class _Game {
  doc;
  meta;
  codeFiles;
  codeMeta;
  paletteArray;
  spritesMap;
  flagsMap;
  tilesMap;
  /**
   * The sheets and the maps a game has, beyond the first of each.
   *
   * The first entry of either names the content already under `gfx.sprites`, `gfx.flags` and
   * `map.tiles` rather than holding its own -- see {@link FIRST_SHEET_ID}.
   */
  sheetsMap;
  mapsMap;
  instruments;
  patterns;
  sfx;
  songs;
  samples;
  netPermissions;
  /**
   * Palette indices of the first sheet, row-major, one byte a pixel.
   *
   * The first sheet's mirror under an older name, and nothing more: it is built, hydrated and
   * reshaped by exactly the code that does it for every other sheet. Replaced when the sheet is
   * resized, so hold it for the length of a draw and no longer.
   */
  get sheet() {
    return this.sheets[0]?.pixels ?? NO_PIXELS;
  }
  /** One byte of flags per sprite, for the first sheet. */
  get flags() {
    return this.sheets[0]?.flags ?? NO_PIXELS;
  }
  /**
   * Sprite numbers of the first map, row-major, one per tile.
   *
   * Sixteen bits rather than eight: a sheet may hold more than 256 sprites, and a tile that could
   * not name them would put most of a sheet out of a map's reach.
   */
  get tiles() {
    return this.maps[0]?.tiles ?? NO_TILES;
  }
  _geometry;
  geometryListeners = /* @__PURE__ */ new Set();
  collectionListeners = /* @__PURE__ */ new Set();
  sheetMirrors = /* @__PURE__ */ new Map();
  /** The projections as last built, or null once the document has moved under them. */
  sheetsHeld = null;
  mapsHeld = null;
  /**
   * How a Sheet reaches the document.
   *
   * A separate object rather than the game itself: Game already has setPixel and setFlag, and they
   * mean the first sheet's -- two things called the same thing, one of which silently ignores the
   * sheet you meant, is the sort of collision that only shows up in someone's lost art.
   */
  sheetWriter = {
    setPixel: (id, x, y, colour) => {
      this.writeSheetPixel(id, x, y, colour);
    },
    setFlag: (id, local, value) => {
      this.writeSheetFlag(id, local, value);
    }
  };
  mapMirrors = /* @__PURE__ */ new Map();
  mapWriter = {
    setTile: (id, x, y, sprite) => {
      this.writeMapTile(id, x, y, sprite);
    }
  };
  /** Cell maps already watched, so a second pass over the collection does not double up. */
  watchedCells = /* @__PURE__ */ new WeakSet();
  pixelListeners = /* @__PURE__ */ new Set();
  tileListeners = /* @__PURE__ */ new Set();
  flagListeners = /* @__PURE__ */ new Set();
  paletteListeners = /* @__PURE__ */ new Set();
  constructor(doc) {
    this.doc = doc;
    this.meta = doc.getMap(KEYS.meta);
    this.codeFiles = doc.getMap(KEYS.codeFiles);
    this.codeMeta = doc.getMap(KEYS.codeMeta);
    this.paletteArray = doc.getArray(KEYS.palette);
    this.spritesMap = doc.getMap(KEYS.sprites);
    this.flagsMap = doc.getMap(KEYS.flags);
    this.tilesMap = doc.getMap(KEYS.tiles);
    this.sheetsMap = doc.getMap(KEYS.sheets);
    this.mapsMap = doc.getMap(KEYS.maps);
    this.instruments = doc.getMap(KEYS.instruments);
    this.patterns = doc.getMap(KEYS.patterns);
    this.sfx = doc.getMap(KEYS.sfx);
    this.songs = doc.getMap(KEYS.songs);
    this.samples = doc.getMap(KEYS.samples);
    this.netPermissions = doc.getMap(KEYS.netPermissions);
    this._geometry = readGeometry(this.meta);
    this.attachSheetObservers();
    this.attachMapObservers();
    const told = () => {
      this.collectionListeners.forEach((l) => {
        l();
      });
    };
    this.sheetsMap.observeDeep(() => {
      this.forgetProjections();
      this.attachSheetObservers();
      told();
    });
    this.mapsMap.observeDeep(() => {
      this.forgetProjections();
      this.attachMapObservers();
      told();
    });
    this.meta.observe((e) => {
      const sized = Object.values(GEOMETRY_KEYS).some((k) => e.changes.keys.has(k));
      if (sized) this.applyGeometry();
    });
    this.paletteArray.observe(() => {
      this.paletteListeners.forEach((l) => {
        l();
      });
    });
  }
  // ---- sheets and maps ------------------------------------------------------
  /** Entries of a collection, sorted the way code files are: by order, then by name. */
  orderedEntries(from) {
    const out = [];
    from.forEach((entry, id) => {
      out.push([id, entry]);
    });
    return out.sort(
      (a, b) => numberOf(a[1], "order", 0) - numberOf(b[1], "order", 0) || a[0].localeCompare(b[0])
    );
  }
  /**
   * The live pixel and flag mirrors of one sheet, made on first ask and reshaped when it resizes.
   *
   * Every sheet the same, the first one included: its cells are at the document's roots rather
   * than under its entry, and `cellsOf` is the one place that knows it. Anything outside the shape
   * is dropped rather than refused -- a document written larger and opened smaller is not corrupt,
   * it is one this reader can only show part of, and nothing here writes back.
   */
  sheetMirror(id, size) {
    const { width, height } = size;
    const held = this.sheetMirrors.get(id);
    if (held?.width === width && held.height === height) return held;
    const count = width / SPRITE_SIZE * (height / SPRITE_SIZE);
    const made = {
      pixels: new Uint8Array(width * height),
      flags: new Uint8Array(count),
      width,
      height
    };
    this.cellsOf(id, "pixels")?.forEach((v, k) => {
      const [x, y] = parseCoord(k);
      if (x >= 0 && x < width && y >= 0 && y < height) made.pixels[y * width + x] = v & 15;
    });
    this.cellsOf(id, "flags")?.forEach((v, k) => {
      const i = Number(k);
      if (i >= 0 && i < count) made.flags[i] = v & 255;
    });
    this.sheetMirrors.set(id, made);
    return made;
  }
  mapMirror(id, size) {
    const { width, height } = size;
    const held = this.mapMirrors.get(id);
    if (held?.width === width && held.height === height) return held;
    const made = { tiles: new Uint16Array(width * height), width, height };
    this.mapCellsOf(id)?.forEach((v, k) => {
      const [x, y] = parseCoord(k);
      if (x >= 0 && x < width && y >= 0 && y < height) made.tiles[y * width + x] = v & 65535;
    });
    this.mapMirrors.set(id, made);
    return made;
  }
  /**
   * Drops the held projections, so the next read builds them from the document.
   *
   * Called from the collection observers and from a geometry change, which between them see every
   * write that can alter a projection: an entry added, removed, renamed, reordered or resized,
   * locally or from a peer, and a first sheet or map resized through the document's meta. A cell
   * written into a mirror is not one of them -- the mirror is the same buffer the projection holds.
   */
  forgetProjections() {
    this.sheetsHeld = null;
    this.mapsHeld = null;
  }
  /**
   * Every sheet, in order, with its sprite numbers already worked out.
   *
   * A document that declares none has one all the same: an empty entry, which takes the document's
   * geometry the way any sheet that states no size of its own does. Written that way rather than as
   * a sheet built by hand, so the one below is the only place a sheet is ever made.
   *
   * Held between document changes: the renderer asks for the sheet of every sprite it draws, and
   * walking Yjs for each would cost a frame its budget. Inside a local transaction the held array
   * lags the write until the observers run at its end; the two reads that happen there -- the
   * order an added entry takes, and the shape a renumbering started from -- want exactly the
   * answer from before the write.
   */
  get sheets() {
    if (this.sheetsHeld) return this.sheetsHeld;
    let base = 0;
    return this.sheetsHeld = this.entriesOrDefault(this.sheetsMap, FIRST_SHEET_ID).map(
      ([id, e], i) => {
        const { width, height } = this.sizeOf(id);
        const mirror = this.sheetMirror(id, { width, height });
        const sheet = new Sheet(
          id,
          stringOf(e, "name", ""),
          numberOf(e, "order", i),
          width,
          height,
          base,
          colourOf(e),
          mirror.pixels,
          mirror.flags,
          this.sheetWriter
        );
        base += sheet.count;
        return sheet;
      }
    );
  }
  get maps() {
    if (this.mapsHeld) return this.mapsHeld;
    return this.mapsHeld = this.entriesOrDefault(this.mapsMap, FIRST_MAP_ID).map(([id, e], i) => {
      const { width, height } = this.mapSizeOf(id);
      return new GameMap(
        id,
        stringOf(e, "name", ""),
        numberOf(e, "order", i),
        width,
        height,
        colourOf(e),
        this.mapMirror(id, { width, height }).tiles,
        this.mapWriter
      );
    });
  }
  /**
   * A collection's entries, or the one every game has when it declares nothing.
   *
   * The empty entry is not written to the document -- reading a game must not change it -- it only
   * stands in so that the first sheet and the first map are built by the same code as the rest.
   */
  entriesOrDefault(from, firstId) {
    const entries = this.orderedEntries(from);
    return entries.length ? entries : [[firstId, new Y.Map()]];
  }
  /**
   * Where a sheet's cells are, or nothing where it has none yet.
   *
   * The first sheet's are the document's own roots -- `gfx.sprites` and `gfx.flags` -- because a
   * game written before a game could have several put them there, and moving them would make this
   * build's documents unreadable to that one. **This is the one place that knows it**, and its
   * twin below is the one place that knows where its size is. Everything else treats every sheet
   * alike.
   */
  cellsOf(sheetId, key) {
    if (sheetId === FIRST_SHEET_ID) return key === "pixels" ? this.spritesMap : this.flagsMap;
    const held = this.sheetsMap.get(sheetId)?.get(key);
    return held instanceof Y.Map ? held : null;
  }
  /** Where the first map's tiles are, and where any other map's would be. */
  mapCellsOf(mapId) {
    if (mapId === FIRST_MAP_ID) return this.tilesMap;
    const held = this.mapsMap.get(mapId)?.get("tiles");
    return held instanceof Y.Map ? held : null;
  }
  /**
   * How big a sheet is: what its entry states, or the document's geometry where it states nothing.
   *
   * The same rule for every sheet. The geometry is not the first sheet's private size, it is the
   * default a sheet takes when it names none -- which is the state every sheet of every game
   * written before collections is in.
   */
  sizeOf(sheetId) {
    const { sheetWidth, sheetHeight } = this._geometry;
    const entry = this.sheetsMap.get(sheetId);
    return {
      width: clampSheetSize(entry ? numberOf(entry, "w", sheetWidth) : sheetWidth),
      height: clampSheetSize(entry ? numberOf(entry, "h", sheetHeight) : sheetHeight)
    };
  }
  /**
   * Writes a sheet's size where `sizeOf` reads it -- on its entry, for every sheet alike.
   *
   * The first sheet's is mirrored into the geometry as well, and that is the whole of what is
   * special about it: `meta.sheetWidth` is where a build from before collections reads the size of
   * the only sheet it knows about, and where this one takes its default from. Mirrored rather than
   * chosen between, because a size written in one of the two places and read from the other is how
   * a picture comes to be read at one width out of a buffer laid out at another.
   */
  writeSheetSize(sheetId, width, height) {
    const w = clampSheetSize(width);
    const h = clampSheetSize(height);
    if (sheetId === FIRST_SHEET_ID) {
      this.declareFirstSheet();
      this.meta.set(GEOMETRY_KEYS.sheetWidth, w);
      this.meta.set(GEOMETRY_KEYS.sheetHeight, h);
    }
    const entry = this.sheetsMap.get(sheetId);
    if (!entry) return;
    entry.set("w", w);
    entry.set("h", h);
  }
  /** The same, for a map. */
  writeMapSize(mapId, width, height) {
    const w = clampMapSize(width);
    const h = clampMapSize(height);
    if (mapId === FIRST_MAP_ID) {
      this.declareFirstMap();
      this.meta.set(GEOMETRY_KEYS.mapWidth, w);
      this.meta.set(GEOMETRY_KEYS.mapHeight, h);
    }
    const entry = this.mapsMap.get(mapId);
    if (!entry) return;
    entry.set("w", w);
    entry.set("h", h);
  }
  /** The same, for a map. */
  mapSizeOf(mapId) {
    const { mapWidth, mapHeight } = this._geometry;
    const entry = this.mapsMap.get(mapId);
    return {
      width: clampMapSize(entry ? numberOf(entry, "w", mapWidth) : mapWidth),
      height: clampMapSize(entry ? numberOf(entry, "h", mapHeight) : mapHeight)
    };
  }
  /**
   * Where a sheet's cells go when something writes to them.
   *
   * Made on the first write rather than at creation, so a sheet nobody has drawn on costs the
   * document nothing.
   */
  sheetCells(sheetId, key) {
    const held = this.cellsOf(sheetId, key);
    if (held) return held;
    const entry = this.sheetsMap.get(sheetId);
    if (!entry) throw new Error(`no sheet ${sheetId}`);
    const made = new Y.Map();
    entry.set(key, made);
    return made;
  }
  /**
   * The tile twin of `sheetCells`: a map's cells, made the first time something writes one.
   *
   * Not watched here: a map made and written in one transaction fires no event of its own, Yjs
   * only reporting on types that were there when the transaction began. The collection observer
   * watches it once the transaction ends, and tells the tiles it arrived with.
   */
  mapCells(mapId) {
    const held = this.mapCellsOf(mapId);
    if (held) return held;
    const entry = this.mapsMap.get(mapId);
    if (!entry) throw new Error(`no map ${mapId}`);
    const made = new Y.Map();
    entry.set("tiles", made);
    return made;
  }
  /** Watches the cell maps of every sheet that has any, once each. */
  attachSheetObservers() {
    for (const id of [FIRST_SHEET_ID, ...this.sheetsMap.keys()])
      for (const key of ["pixels", "flags"]) {
        const cells = this.cellsOf(id, key);
        if (!cells || this.watchedCells.has(cells)) continue;
        this.watchedCells.add(cells);
        this.observeSheetCells(id, key, cells);
        this.tellCells(id, key, cells, cells.keys());
      }
  }
  /** The same for the maps, whose tiles the first one keeps at the document's root. */
  attachMapObservers() {
    for (const id of [FIRST_MAP_ID, ...this.mapsMap.keys()]) {
      const cells = this.mapCellsOf(id);
      if (!cells || this.watchedCells.has(cells)) continue;
      this.watchedCells.add(cells);
      this.observeMapCells(id, cells);
      this.tellTiles(id, cells, cells.keys());
    }
  }
  /**
   * Keeps one sheet's mirror in step with its cells.
   *
   * Attached as the cell maps appear, so the listeners hear about them the same way -- a peer
   * drawing on a sheet nobody has opened still has to reach the screen.
   */
  /** Brings a sheet's mirror in step with these cells and tells the listeners what moved. */
  tellCells(sheetId, key, cells, keys) {
    const sheet = this.sheets.find((s) => s.id === sheetId);
    if (!sheet) return;
    const changes = [];
    for (const k of keys) {
      if (key === "flags") {
        const i = Number(k);
        if (i >= 0 && i < sheet.count) sheet.flags[i] = (cells.get(k) ?? 0) & 255;
        continue;
      }
      const [x, y] = parseCoord(k);
      if (x < 0 || x >= sheet.width || y < 0 || y >= sheet.height) continue;
      const colour = (cells.get(k) ?? 0) & 15;
      sheet.pixels[y * sheet.width + x] = colour;
      changes.push({ sheet: sheetId, x, y, colour });
    }
    if (key === "flags")
      this.flagListeners.forEach((l) => {
        l();
      });
    else if (changes.length)
      this.pixelListeners.forEach((l) => {
        l(changes);
      });
  }
  observeSheetCells(sheetId, key, cells) {
    cells.observe((e) => {
      this.tellCells(sheetId, key, cells, e.changes.keys.keys());
    });
  }
  /** Brings the mirror in step with these cells and tells the listeners which tiles moved. */
  tellTiles(mapId, cells, keys) {
    const map = this.maps.find((m) => m.id === mapId);
    if (!map) return;
    const changes = [];
    for (const k of keys) {
      const [x, y] = parseCoord(k);
      if (x < 0 || x >= map.width || y < 0 || y >= map.height) continue;
      const sprite = (cells.get(k) ?? 0) & 65535;
      map.tiles[y * map.width + x] = sprite;
      changes.push({ map: mapId, x, y, sprite });
    }
    if (changes.length)
      this.tileListeners.forEach((l) => {
        l(changes);
      });
  }
  /** The tile twin of `observeSheetCells`. */
  observeMapCells(mapId, cells) {
    cells.observe((e) => {
      this.tellTiles(mapId, cells, e.changes.keys.keys());
    });
  }
  writeSheetPixel(sheetId, x, y, colour) {
    const cells = this.sheetCells(sheetId, "pixels");
    const key = coordKey(x, y);
    if (colour === 0) {
      if (cells.has(key)) cells.delete(key);
    } else cells.set(key, colour & 15);
  }
  writeSheetFlag(sheetId, local, value) {
    const cells = this.sheetCells(sheetId, "flags");
    const key = String(local);
    const v = value & 255;
    if (v === 0) {
      if (cells.has(key)) cells.delete(key);
    } else cells.set(key, v);
  }
  writeMapTile(mapId, x, y, sprite) {
    const cells = this.mapCells(mapId);
    const key = coordKey(x, y);
    if (sprite === 0) {
      if (cells.has(key)) cells.delete(key);
    } else cells.set(key, sprite & 65535);
  }
  /**
   * Adds a sheet after the ones there are, and gives it the numbers that follow theirs.
   *
   * The first call also writes the entry for the sheet that was already there, because a document
   * cannot hold a second sheet without saying what the first one is.
   */
  addSheet(name, width, height, id = crypto.randomUUID()) {
    this.doc.transact(() => {
      this.declareFirstSheet();
      const order = this.sheets.reduce((m, sh) => Math.max(m, sh.order), -1) + 1;
      const entry = new Y.Map();
      this.sheetsMap.set(id, entry);
      entry.set("name", name);
      entry.set("order", order);
      entry.set("w", clampSheetSize(width));
      entry.set("h", clampSheetSize(height));
    }, LOCAL_ORIGIN);
  }
  /** Resizes a sheet other than the first, whose size is the document's own. */
  /**
   * What resizing a sheet would cost, without doing it.
   *
   * A sheet's pixels are kept by position, so a resize keeps the picture and re-flows the grid of
   * numbers over it: the same cell answers to a different number afterwards, and so does every cell
   * of every sheet after this one. Anything that named a number by hand has to follow.
   */
  previewResize(id, width, height) {
    const before = this.sheets;
    const after = this.shapesAfterResize(id, width, height);
    const moves = remapSprites(before, after);
    let tiles = 0;
    for (const m of this.maps)
      for (const n of m.tiles)
        if (n !== 0 && (moves.has(n) || !survives(n, before, after))) tiles++;
    let calls = 0;
    let unsure = 0;
    for (const f of this.files) {
      const out = rewriteSpriteNumbers(f.text.toString(), moves);
      calls += out.changed;
      unsure += out.unsure;
    }
    let lost = 0;
    for (const sh of before)
      for (let n = sh.base; n < sh.base + sh.count; n++)
        if (!survives(n, before, after) && !sh.isEmpty(n)) lost++;
    return { moves: moves.size, tiles, calls, unsure, lost };
  }
  /**
   * Resizes a sheet and brings everything that named a sprite number along with it.
   *
   * One transaction for the sizes, the flags, the tiles and the code: a document caught halfway is
   * one where a number means two things at once, and a peer joining then would read exactly that.
   */
  resizeSheet(id, width, height) {
    const before = this.sheets;
    if (!before.some((sh) => sh.id === id)) return;
    const after = this.shapesAfterResize(id, width, height);
    const held = this.holdNumbered();
    this.doc.transact(() => {
      this.writeSheetSize(id, width, height);
      this.renumber(before, after, held);
    }, LOCAL_ORIGIN);
  }
  /**
   * Resizes one map. Nothing is renumbered: a tile keeps its place, and the first map's size
   * reaches the geometry through the writer, as it always did.
   */
  resizeMap(id, width, height) {
    if (!this.maps.some((m) => m.id === id)) return;
    this.doc.transact(() => {
      this.writeMapSize(id, width, height);
    }, LOCAL_ORIGIN);
  }
  /**
   * Everything that names a sprite by number, copied out before the sizes move.
   *
   * Read first because the projections below are rebuilt from the document on every access: once
   * the sizes have changed they describe the new arrangement, and what has to be moved is what the
   * old one said.
   */
  holdNumbered() {
    return {
      flags: this.sheets.map((sh) => ({ id: sh.id, base: sh.base, values: Array.from(sh.flags) })),
      tiles: this.maps.map((m) => ({ id: m.id, width: m.width, values: Array.from(m.tiles) }))
    };
  }
  /**
   * Moves the tiles, the flags and the code onto the numbers the new shape gives them.
   *
   * Written straight into the document's maps rather than through `setFlag` and `setTile`: this
   * runs inside the same transaction as the resize, and until that transaction ends the observers
   * have not fired, so those two are still guarding against the sizes the game had a moment ago.
   * The new shape is passed in for the same reason.
   */
  renumber(before, after, held) {
    const moves = remapSprites(before, after);
    if (moves.size === 0) return;
    const kept = (n) => moves.get(n) ?? (survives(n, before, after) ? n : NOT_A_SPRITE);
    for (const sh of held.flags) {
      const now = after.find((s) => s.id === sh.id);
      if (!now) continue;
      const cells = now.width / SPRITE_SIZE * (now.height / SPRITE_SIZE);
      const next = /* @__PURE__ */ new Map();
      sh.values.forEach((v, local) => {
        if (v === 0) return;
        const to = kept(sh.base + local);
        if (to !== NOT_A_SPRITE) next.set(to - now.base, v);
      });
      const target = this.sheetCells(now.id, "flags");
      target.forEach((_v, k) => {
        target.delete(k);
      });
      for (let i = 0; i < cells; i++) {
        const v = next.get(i);
        if (v) target.set(String(i), v);
      }
    }
    for (const m of held.tiles) {
      if (!m.values.some((n) => n !== 0)) continue;
      const tiles = this.mapCells(m.id);
      m.values.forEach((n, at) => {
        if (n === 0) return;
        const to = kept(n);
        const key = coordKey(at % m.width, Math.floor(at / m.width));
        if (to === NOT_A_SPRITE || to === 0) tiles.delete(key);
        else tiles.set(key, to & 65535);
      });
    }
    for (const f of this.files) {
      const out = rewriteSpriteNumbers(f.text.toString(), moves);
      if (out.changed === 0) continue;
      f.text.delete(0, f.text.length);
      f.text.insert(0, out.text);
    }
  }
  /** The sheets as they would be, in order, if this one took that size. */
  shapesAfterResize(id, width, height) {
    let base = 0;
    return this.sheets.map((sh) => {
      const w = sh.id === id ? clampSheetSize(width) : sh.width;
      const h = sh.id === id ? clampSheetSize(height) : sh.height;
      const at = base;
      base += w / SPRITE_SIZE * (h / SPRITE_SIZE);
      return {
        id: sh.id,
        name: sh.name,
        order: sh.order,
        colour: sh.colour,
        width: w,
        height: h,
        base: at
      };
    });
  }
  /** A colour of null takes none, rather than taking slot zero. */
  describeSheet(id, name, colour) {
    this.doc.transact(() => {
      this.declareFirstSheet();
      this.describe(this.sheetsMap, id, name, colour);
    }, LOCAL_ORIGIN);
  }
  describeMap(id, name, colour) {
    this.doc.transact(() => {
      this.declareFirstMap();
      this.describe(this.mapsMap, id, name, colour);
    }, LOCAL_ORIGIN);
  }
  describe(from, id, name, colour) {
    const entry = from.get(id);
    if (!entry) return;
    this.doc.transact(() => {
      entry.set("name", name);
      if (colour === null) entry.delete("colour");
      else entry.set("colour", colour);
    }, LOCAL_ORIGIN);
  }
  /** Refuses the last one, the way a code file does: a game with no sheet has nowhere to draw. */
  removeSheet(id) {
    if (this.sheetsMap.size <= 1) return;
    this.doc.transact(() => {
      this.sheetsMap.delete(id);
      this.sheetMirrors.delete(id);
    }, LOCAL_ORIGIN);
  }
  addMap(name, width, height, id = crypto.randomUUID()) {
    this.doc.transact(() => {
      this.declareFirstMap();
      const order = this.maps.reduce((m, mp) => Math.max(m, mp.order), -1) + 1;
      const entry = new Y.Map();
      this.mapsMap.set(id, entry);
      entry.set("name", name);
      entry.set("order", order);
      entry.set("w", clampMapSize(width));
      entry.set("h", clampMapSize(height));
    }, LOCAL_ORIGIN);
  }
  removeMap(id) {
    if (this.mapsMap.size <= 1) return;
    this.doc.transact(() => {
      this.mapsMap.delete(id);
      this.mapMirrors.delete(id);
    }, LOCAL_ORIGIN);
  }
  /**
   * Writes the entry describing the sheet a document already had.
   *
   * Its key is fixed rather than fresh, so two clients doing this at once write the same entry
   * instead of splitting one sheet into two -- the same reason the entry file's key is fixed.
   */
  declareFirstSheet() {
    if (this.sheetsMap.size > 0) return;
    const entry = new Y.Map();
    this.sheetsMap.set(FIRST_SHEET_ID, entry);
    entry.set("order", 0);
    entry.set("w", this._geometry.sheetWidth);
    entry.set("h", this._geometry.sheetHeight);
  }
  declareFirstMap() {
    if (this.mapsMap.size > 0) return;
    const entry = new Y.Map();
    this.mapsMap.set(FIRST_MAP_ID, entry);
    entry.set("order", 0);
    entry.set("w", this._geometry.mapWidth);
    entry.set("h", this._geometry.mapHeight);
  }
  /** Which sheet answers to a sprite number, or nothing where the number names no cell. */
  sheetOf(sprite) {
    return this.sheets.find((s) => s.holds(sprite));
  }
  mapOf(id) {
    return this.maps.find((m) => m.id === id);
  }
  /** One past the highest sprite number any sheet claims. */
  get spriteTotal() {
    return this.sheets.reduce((n, s) => n + s.count, 0);
  }
  // ---- geometry -------------------------------------------------------------
  /** How big this game's sheet and map are. Read it per use; a resize replaces it. */
  get geometry() {
    return this._geometry;
  }
  onGeometryChange(fn) {
    this.geometryListeners.add(fn);
    return () => this.geometryListeners.delete(fn);
  }
  /**
   * Told when a sheet or a map is added, removed or renamed.
   *
   * The collections are Yjs maps, not signals, so anything derived from them has no way of its own
   * to know it has gone stale -- and two things derived from the same collection at different
   * moments will disagree, which is how a panel came to show three sheets beside a count of one.
   */
  onCollectionsChange(fn) {
    this.collectionListeners.add(fn);
    return () => this.collectionListeners.delete(fn);
  }
  /**
   * Takes a size the document now states, and says so.
   *
   * Nothing is reshaped here: a mirror carries the shape it was built at and `sheetMirror` makes a
   * new one the moment it is asked for a different one, so the next read does it.
   */
  applyGeometry() {
    const next = readGeometry(this.meta);
    if (next.sheetWidth === this._geometry.sheetWidth && next.sheetHeight === this._geometry.sheetHeight && next.mapWidth === this._geometry.mapWidth && next.mapHeight === this._geometry.mapHeight)
      return;
    this._geometry = next;
    this.forgetProjections();
    this.geometryListeners.forEach((l) => {
      l();
    });
  }
  /**
   * Records a new size. Pixels and tiles outside it stay in the document but stop being reachable,
   * so growing back finds them again -- which is what makes a mis-click survivable.
   */
  resize(size) {
    const sheetWidth = size.sheetWidth ?? this._geometry.sheetWidth;
    const sheetHeight = size.sheetHeight ?? this._geometry.sheetHeight;
    const before = this.sheets;
    const after = this.shapesAfterResize(FIRST_SHEET_ID, sheetWidth, sheetHeight);
    const held = this.holdNumbered();
    this.doc.transact(() => {
      if (size.sheetWidth !== void 0 || size.sheetHeight !== void 0)
        this.writeSheetSize(FIRST_SHEET_ID, sheetWidth, sheetHeight);
      if (size.mapWidth !== void 0 || size.mapHeight !== void 0)
        this.writeMapSize(
          FIRST_MAP_ID,
          size.mapWidth ?? this._geometry.mapWidth,
          size.mapHeight ?? this._geometry.mapHeight
        );
      this.renumber(before, after, held);
    }, LOCAL_ORIGIN);
  }
  // ---- meta -----------------------------------------------------------------
  get schemaVersion() {
    const v = this.meta.get("schemaVersion");
    return typeof v === "number" ? v : 0;
  }
  get compat() {
    return this.meta.get("compat") !== false;
  }
  /**
   * The names the game gives its actions, typed in the GAME tab and persisted so the controls table
   * and the public "how to play" can show them without running the game. Empty when it names none,
   * in which case callers fall back to the engine's action ids.
   */
  get declaredActions() {
    const raw = this.meta.get("actions");
    if (!Array.isArray(raw)) return [];
    return raw.filter(
      (a) => typeof a === "object" && a !== null && isAction(a.action) && typeof a.label === "string"
    );
  }
  /** An action with a blank label is an action left unnamed, so it is not written at all. */
  setDeclaredActions(actions) {
    const next = actions.map((a) => ({ action: a.action, label: a.label.trim() })).filter((a) => a.label.length > 0);
    if (JSON.stringify(next) === JSON.stringify(this.declaredActions)) return;
    this.doc.transact(() => {
      this.meta.set("actions", next);
    }, LOCAL_ORIGIN);
  }
  // ---- palette --------------------------------------------------------------
  get palette() {
    const p = this.paletteArray.toArray();
    if (p.length === PALETTE_SIZE) return p;
    return [...BUBBLEGUM_16];
  }
  setPaletteColour(index, hex) {
    if (index < 0 || index >= PALETTE_SIZE) return;
    this.doc.transact(() => {
      if (this.paletteArray.length !== PALETTE_SIZE) {
        this.paletteArray.delete(0, this.paletteArray.length);
        this.paletteArray.insert(0, [...BUBBLEGUM_16]);
      }
      this.paletteArray.delete(index, 1);
      this.paletteArray.insert(index, [hex.toLowerCase()]);
    }, LOCAL_ORIGIN);
  }
  setPalette(colours) {
    this.doc.transact(() => {
      this.paletteArray.delete(0, this.paletteArray.length);
      this.paletteArray.insert(
        0,
        colours.slice(0, PALETTE_SIZE).map((c) => c.toLowerCase())
      );
    }, LOCAL_ORIGIN);
  }
  onPaletteChange(l) {
    this.paletteListeners.add(l);
    return () => this.paletteListeners.delete(l);
  }
  // ---- sprites --------------------------------------------------------------
  /**
   * The first sheet's pixels, which is what `gfx.pixel` and the like have always meant.
   *
   * Asked of the sheet rather than worked out here: a second copy of "where is pixel x,y" is a
   * second chance to disagree with the first the day a sheet is not 128 wide.
   */
  getPixel(x, y) {
    return this.sheets[0]?.getPixel(x, y) ?? 0;
  }
  setPixel(x, y, colour) {
    this.sheets[0]?.setPixel(x, y, colour);
  }
  /** Batch pixel writes into one transaction (one undo step, one network update). */
  transact(fn, origin = LOCAL_ORIGIN) {
    this.doc.transact(fn, origin);
  }
  onPixelsChange(l) {
    this.pixelListeners.add(l);
    return () => this.pixelListeners.delete(l);
  }
  /**
   * Where a sprite number starts, on the sheet that answers to it.
   *
   * The one authority on how a number becomes a position: the renderer and both editors used to
   * each carry their own copy of this arithmetic, and four copies are four chances to disagree the
   * day a number no longer names a place on one fixed sheet.
   *
   * A number no sheet claims lands at the origin of the first, which is what every caller did with
   * an out-of-range number before there was anywhere else for one to be.
   */
  spriteOrigin(index) {
    const sheet = this.sheetOf(index);
    return sheet ? sheet.originOf(index) : { x: 0, y: 0 };
  }
  isSpriteEmpty(index) {
    return this.sheetOf(index)?.isEmpty(index) ?? true;
  }
  // ---- flags ----------------------------------------------------------------
  getFlag(index) {
    return this.flags[index] ?? 0;
  }
  getFlagBit(index, bit) {
    return (this.flags[index] ?? 0) >> bit & 1 ? true : false;
  }
  setFlag(index, value) {
    const first = this.sheets[0];
    if (!first || index < 0 || index >= first.count) return;
    first.setFlag(index, value);
  }
  onFlagsChange(l) {
    this.flagListeners.add(l);
    return () => this.flagListeners.delete(l);
  }
  // ---- map ------------------------------------------------------------------
  /** The first map's tile, as `getPixel` is the first sheet's pixel: the one every game has. */
  getTile(x, y) {
    return this.maps[0]?.getTile(x, y) ?? 0;
  }
  setTile(x, y, sprite) {
    this.maps[0]?.setTile(x, y, sprite);
  }
  onTilesChange(l) {
    this.tileListeners.add(l);
    return () => this.tileListeners.delete(l);
  }
  // ---- code -----------------------------------------------------------------
  get files() {
    const out = [];
    this.codeFiles.forEach((f, id) => {
      const text = f.get("text");
      if (!(text instanceof Y.Text)) return;
      out.push({
        id,
        name: typeof f.get("name") === "string" ? f.get("name") : id,
        order: Number(f.get("order") ?? 0),
        colour: typeof f.get("colour") === "number" ? f.get("colour") : null,
        text
      });
    });
    return out.sort((a, b) => a.order - b.order || a.name.localeCompare(b.name));
  }
  get entryFile() {
    const files = this.files;
    const entryId = this.codeMeta.get("entry");
    return files.find((f) => f.id === entryId) ?? files.find((f) => f.name === MAIN_FILE) ?? files[0];
  }
  /**
   * `id` is only passed when the key has to be reproducible across clients — the entry file, so a
   * concurrent seed converges instead of merging into two entries. Everything else gets a UUID.
   */
  addFile(name, source = "", id = crypto.randomUUID()) {
    const order = this.files.reduce((m, f) => Math.max(m, f.order), -1) + 1;
    this.doc.transact(() => {
      const f = new Y.Map();
      const text = new Y.Text();
      this.codeFiles.set(id, f);
      f.set("name", name);
      f.set("order", order);
      f.set("text", text);
      if (source) text.insert(0, source);
      if (!this.codeMeta.has("entry") && name === MAIN_FILE) this.codeMeta.set("entry", id);
    }, LOCAL_ORIGIN);
    return { id, name, order, colour: null, text: this.codeFiles.get(id)?.get("text") };
  }
  renameFile(id, name) {
    this.codeFiles.get(id)?.set("name", name);
  }
  /**
   * Ids first to last; anything not named keeps its place after them.
   *
   * One transaction rather than one write per file: the order decides what runs when, so every
   * observer downstream reloads the game on it, and N writes would mean N reloads of an order that
   * was only ever moved once.
   */
  reorderFiles(ids) {
    const ranked = new Map(ids.map((id, i) => [id, i]));
    const rest = this.files.filter((f) => !ranked.has(f.id));
    this.doc.transact(() => {
      ids.forEach((id, i) => this.codeFiles.get(id)?.set("order", i));
      rest.forEach((f, i) => this.codeFiles.get(f.id)?.set("order", ids.length + i));
    }, LOCAL_ORIGIN);
  }
  setFileColour(id, colour) {
    const f = this.codeFiles.get(id);
    if (!f) return;
    if (colour === null) f.delete("colour");
    else f.set("colour", colour);
  }
  removeFile(id) {
    if (this.files.length <= 1) return;
    this.doc.transact(() => {
      this.codeFiles.delete(id);
      if (this.codeMeta.get("entry") === id) this.codeMeta.delete("entry");
    }, LOCAL_ORIGIN);
  }
  /**
   * Every file's source in the order the tabs are in — which is the order they are evaluated.
   *
   * A file's name is also the name anything asking for it by name would use.
   */
  sources() {
    return this.files.map((f) => ({ name: f.name, source: f.text.toString() }));
  }
  // ---- sound ----------------------------------------------------------------
  parseMap(map) {
    const out = /* @__PURE__ */ new Map();
    map.forEach((v, k) => {
      try {
        out.set(k, JSON.parse(v));
      } catch {
      }
    });
    return out;
  }
  getInstruments() {
    const out = this.parseMap(this.instruments);
    for (const [, i] of out) {
      i.detune ??= 0;
      i.glide ??= 0;
      const legacy = i.arp.steps;
      if (Array.isArray(legacy) && legacy.length === 0) i.arp = { rate: 0 };
    }
    return out;
  }
  getPatterns() {
    return this.parseMap(this.patterns);
  }
  getSongs() {
    return this.parseMap(this.songs);
  }
  /** sfx slot ("0".."15") → pattern id */
  getSfxSlots() {
    const out = /* @__PURE__ */ new Map();
    this.sfx.forEach((v, k) => out.set(k, v));
    return out;
  }
  setInstrument(i) {
    this.instruments.set(i.id, JSON.stringify(i));
  }
  setPattern(p) {
    this.patterns.set(p.id, JSON.stringify(p));
  }
  setSong(slot, s) {
    this.songs.set(String(slot), JSON.stringify(s));
  }
  // ---- versions -------------------------------------------------------------
  /**
   * Puts a saved snapshot back, as content rather than as history.
   *
   * `Y.applyUpdate` cannot do this, and the editor spent its whole life believing it could. A
   * version blob is `encodeStateAsUpdate` of *this same document* at an earlier moment, so every
   * operation it carries is already in this document: applying it back is, by the CRDT's own
   * rules, a no-op. Restoring a version reported success and changed nothing.
   *
   * So a restore is written as ordinary edits — which is also what makes it reach everyone else in
   * the session, land in the undo stack, and autosave like any other change. Only the differences
   * are written, so restoring a version that only touched code does not rewrite 16k map cells.
   */
  restoreFrom(update) {
    const scratch = new Y.Doc();
    Y.applyUpdate(scratch, update);
    const from = new _Game(scratch);
    try {
      this.doc.transact(() => {
        replaceMap(this.meta, from.meta);
        replaceMap(this.codeMeta, from.codeMeta);
        replaceMap(this.spritesMap, from.spritesMap);
        replaceMap(this.flagsMap, from.flagsMap);
        replaceMap(this.tilesMap, from.tilesMap);
        replaceMap(this.instruments, from.instruments);
        replaceMap(this.patterns, from.patterns);
        replaceMap(this.sfx, from.sfx);
        replaceMap(this.songs, from.songs);
        replaceMap(this.samples, from.samples);
        replaceMap(this.netPermissions, from.netPermissions);
        replaceMap(this.doc.getMap("ai.catalog"), scratch.getMap("ai.catalog"));
        replaceMap(this.doc.getMap("ai.levels"), scratch.getMap("ai.levels"));
        replaceMap(this.doc.getMap("ai.locks"), scratch.getMap("ai.locks"));
        replaceArray(this.paletteArray, from.paletteArray);
        this.restoreFiles(from);
        this.restoreCollection(this.sheetsMap, from.sheetsMap);
        this.restoreCollection(this.mapsMap, from.mapsMap);
        for (const key of RESTORED_TEXTS) {
          replaceText(this.doc.getText(key), scratch.getText(key).toString());
        }
      }, LOCAL_ORIGIN);
    } finally {
      scratch.destroy();
    }
  }
  /**
   * Sheets and maps are entries holding their own nested maps of cells, so — like files — they
   * cannot be copied by value. An entry the snapshot does not have goes, or restoring an old
   * version would leave today's sheets standing beside it and the game would be two states at once.
   */
  restoreCollection(into, from) {
    for (const id of [...into.keys()]) if (!from.has(id)) into.delete(id);
    from.forEach((entry, id) => {
      const made = new Y.Map();
      into.set(id, made);
      entry.forEach((value, key) => {
        if (value instanceof Y.Map) {
          const cells = new Y.Map();
          made.set(key, cells);
          value.forEach((v, k) => {
            cells.set(k, v);
          });
          return;
        }
        made.set(key, value);
      });
    });
  }
  /** Files are maps of maps holding a `Y.Text`, so they cannot be copied by value. */
  restoreFiles(from) {
    for (const id of [...this.codeFiles.keys()]) {
      if (!from.codeFiles.has(id)) this.codeFiles.delete(id);
    }
    from.codeFiles.forEach((source, id) => {
      let target = this.codeFiles.get(id);
      if (!target) {
        target = new Y.Map();
        this.codeFiles.set(id, target);
        target.set("text", new Y.Text());
      }
      const name = source.get("name");
      const order = source.get("order");
      if (target.get("name") !== name) target.set("name", name);
      if (target.get("order") !== order) target.set("order", order);
      const text = target.get("text");
      const wanted = source.get("text");
      if (text instanceof Y.Text && wanted instanceof Y.Text) {
        replaceText(text, wanted.toString());
      }
    });
  }
  // ---- seeding --------------------------------------------------------------
  /** Fills an empty document with the starter game. Idempotent. */
  seedDefaults() {
    this.doc.transact(() => {
      if (!this.meta.has("schemaVersion")) {
        this.meta.set("schemaVersion", GAME_SCHEMA_VERSION);
        this.meta.set("compat", false);
      }
      if (this.paletteArray.length !== PALETTE_SIZE) {
        this.paletteArray.delete(0, this.paletteArray.length);
        this.paletteArray.insert(0, [...BUBBLEGUM_16]);
      }
      if (this.files.length === 0) {
        this.addFile(MAIN_FILE, DEFAULT_GAME_CODE, MAIN_FILE_ID);
        if (DEFAULT_PLAYER_SPRITE_INDICES.every((i) => this.isSpriteEmpty(i)))
          this.seedDefaultSprite(DEFAULT_SPRITE_COLOUR);
      }
      this.dedupeEntryFile();
    }, LOCAL_ORIGIN);
  }
  /**
   * Repairs a document seeded twice before {@link MAIN_FILE_ID} existed.
   *
   * Conservative on purpose: it keeps whichever entry holds the most text and drops the others
   * only when they are empty or hold exactly the same source. A duplicate that somehow diverged is
   * left alone and renamed out of the way, because losing a line of someone's Lua to a tidy-up is
   * worse than an odd file name.
   */
  dedupeEntryFile() {
    const mains = this.files.filter((f) => f.name === MAIN_FILE);
    if (mains.length < 2) return;
    const keep = mains.reduce((a, b) => b.text.length > a.text.length ? b : a);
    const kept = keep.text.toString();
    for (const f of mains) {
      if (f.id === keep.id) continue;
      const source = f.text.toString();
      if (source === "" || source === kept) this.codeFiles.delete(f.id);
      else this.codeFiles.get(f.id)?.set("name", `main recovered ${f.id.slice(0, 6)}`);
    }
    this.codeMeta.set("entry", keep.id);
  }
  seedDefaultSprite(colour) {
    const quads = [
      [1, 0, 0],
      [2, 8, 0],
      [17, 0, 8],
      [18, 8, 8]
    ];
    for (const [index, sx, sy] of quads) {
      const o = this.spriteOrigin(index);
      for (let y = 0; y < SPRITE_SIZE; y++)
        for (let x = 0; x < SPRITE_SIZE; x++)
          if (DEFAULT_PLAYER_SPRITE[sy + y]?.[sx + x] === "a")
            this.setPixel(o.x + x, o.y + y, colour);
    }
  }
};

// src/game/ai.ts
var AI_KEYS = {
  catalog: "ai.catalog",
  levels: "ai.levels",
  locks: "ai.locks",
  applied: "ai.applied"
};
var hexPixels = (pixels) => {
  let out = "";
  for (const value of pixels) out += (value & 15).toString(16);
  return out;
};
function aiContext(game) {
  return {
    schemaVersion: game.schemaVersion,
    palette: game.palette,
    encoding: { sheetPixels: "one hex digit per pixel, row-major" },
    code: game.files.map((file) => ({ id: file.id, name: file.name, text: file.text.toString() })),
    sheets: game.sheets.map((sheet) => ({
      id: sheet.id,
      name: sheet.name,
      width: sheet.width,
      height: sheet.height,
      base: sheet.base,
      pixels: hexPixels(sheet.pixels),
      flags: Array.from(sheet.flags)
    })),
    maps: game.maps.map((map) => ({
      id: map.id,
      name: map.name,
      width: map.width,
      height: map.height,
      tiles: Array.from(map.tiles)
    })),
    catalog: game.doc.getMap(AI_KEYS.catalog).toJSON(),
    levels: game.doc.getMap(AI_KEYS.levels).toJSON(),
    locks: game.doc.getMap(AI_KEYS.locks).toJSON(),
    instruments: game.instruments.toJSON(),
    patterns: game.patterns.toJSON(),
    songs: game.songs.toJSON(),
    sfx: game.sfx.toJSON(),
    samples: Object.keys(game.samples.toJSON()),
    // What each declared net.state path may be reached by, and what a session starts it at. The
    // live values are not here and cannot be: they belong to a running session, not the document.
    netPermissions: Object.fromEntries(game.netPermissions.entries())
  };
}
function encodeState(doc) {
  const update = Y2.encodeStateAsUpdate(doc);
  let binary = "";
  for (let i = 0; i < update.length; i += 8192)
    binary += String.fromCharCode(...update.subarray(i, i + 8192));
  return btoa(binary);
}
function gameFromState(state) {
  const doc = new Y2.Doc();
  Y2.applyUpdate(
    doc,
    Uint8Array.from(atob(state), (c) => c.charCodeAt(0))
  );
  return new Game(doc);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  DEFAULT_GEOMETRY,
  FIRST_MAP_ID,
  FIRST_SHEET_ID,
  GAME_SCHEMA_VERSION,
  GEOMETRY_KEYS,
  Game,
  KEYS,
  LEGACY_KEYS,
  MAIN_FILE,
  MAIN_FILE_ID,
  MAP_HEIGHT,
  MAP_WIDTH,
  MAX_MAP_SIZE,
  MAX_SHEET_SIZE,
  MIN_MAP_SIZE,
  MIN_SHEET_SIZE,
  PALETTE_SIZE,
  SCREEN_HEIGHT,
  SCREEN_WIDTH,
  SHEET_HEIGHT,
  SHEET_WIDTH,
  SIZE_STEP,
  SPRITES_PER_ROW,
  SPRITE_COUNT,
  SPRITE_SIZE,
  aiContext,
  clampMapSize,
  clampSheetSize,
  encodeState,
  gameFromState,
  geometryOf,
  readGeometry
});
